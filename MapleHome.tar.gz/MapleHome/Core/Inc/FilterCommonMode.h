/*
 * FilterCommonMode.h
 *
 *  Created on: 08-Jul-2020
 *      Author: ubuntu
 */

#ifndef FILTERCOMMONMODE_H_
#define FILTERCOMMONMODE_H_

#include "utility.h"
typedef unsigned int uint_32;


void Averaging(float input[], float output[], uint_32 channels,int samplecount);


#endif /* FILTERCOMMONMODE_H_ */
