/*Private Includes---------------*/
#include "MPLSMapleMain.h"
#include "MPLSMeasurement.h"
#include "MPLMCommandProcessor.h"
#include "MPLSMapleMain.h"
#include "math.h"

#include "FilterHighPass.h"
#include "FilterCommonMode.h"
#include "FilterComb.h"
#include "MPLS_Rms.h"



/*********************Extern Variables *******************/
extern TIM_HandleTypeDef htim1;
extern int deviceStatus;

/*******************Private Global Variables**************/
double array_rms_value[24] ;
//double array2_rms_value[24] ;

float wind_array1[24][100] = { 0 };
float wind_array2[24][100] = { 0 };

float clockPeriod =(int) ((float)(1/(float)STIM_CLOCK_FREQUENCY)*1000000) ;
int measurementState ;
int pulseTotTime ; //In millis
int pulseOffTime ; //In Millis
int pulsePhaseCount ;
int totalPulseCount ;
int periodCounter ;
int sequenceCounter ;
int sample_count ;
int8_t win1_indx ;
int8_t win2_indx ;
uint8_t aryIndex ;
int8_t PocessBufStatus ;
int8_t FillBufStatus = FILLFISTBUF;
bool Measurstatus ;
float mvConvFact;

MEASUREMENT_TypeDef measurementSettings;


bool MPSTM_ExecMeasurementRequest()
{
	if(MPCP_ParseMeasurementRequest() == true)
	{
		MPSTM_StratMeasurement();

	}
	else
	{
		//TODO send back error response;
	}
	return true;
}

void MPSTM_StratMeasurement()
{
	MPSTM_MeasurementTimerInit();
	deviceStatus = STATUS_DEVICE_MESUREMENT_RUNNING;
	mvConvFact = (3.0 /16777215.0) * 1000;
//	Trial check
	//MPCP_SendRespMeasurementProgress(1,2,3);
}
void MPSTM_StopMeasurement()
{
	HAL_TIM_OC_Stop(&htim1, TIM_CHANNEL_1);
}
/*
This function is called once before starting the stimulation process
It calculate the pulse off time in micros using stimulation frequnecy
and pulse phase time.

Loads shift regsiter with source electrode settings. Set MC pins for
Sink electrodes
*/
/*
void MPSTM_InitMeasurementParams()
{
	//Initialize timer values
	measurementState = MEASUREMENT_SATUS_INIT;
	clockPeriod = measurementSettings.pulsePhase;//Counter is programed to generate 50Micro Seccond pulse with pre-scaler . 0.005952380952f;//(int) ((float)(1/(float)STIM_CLOCK_FREQUENCY)*1000000);
	pulseTotTime = (int)((float)(1/(float)measurementSettings.pulseFrequency)*1000000); 	 //Pulse Tot in micros
	pulseOffTime = pulseTotTime - (measurementSettings.pulsePhase*2+50); //Pulse Off Time in micro seconds
																																			 //Electrodes toggles after fisrt phase time , and a dead time of 50 ms between that
	pulsePhaseCount = 	((int)(measurementSettings.pulsePhase));
	totalPulseCount = pulseOffTime/clockPeriod;
	periodCounter = 0;
	sequenceCounter = 0;
	Measurstatus = true;

}
*/
//use it later


void MPSTM_MeasurementTimerInit()
{
	/* USER CODE BEGIN TIM1_Init 0 */

	  /* USER CODE END TIM1_Init 0 */

	  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	  TIM_MasterConfigTypeDef sMasterConfig = {0};

	  /* USER CODE BEGIN TIM1_Init 1 */

	  /* USER CODE END TIM1_Init 1 */
	  htim1.Instance = TIM1;
	  htim1.Init.Prescaler = 168;
	  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
	  htim1.Init.Period = 1111;//for 900 hz
	  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	  htim1.Init.RepetitionCounter = 0;
	  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;

	  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }

	  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  /* USER CODE BEGIN TIM1_Init 2 */
	   HAL_TIM_Base_Start_IT(&htim1);
	  /* USER CODE END TIM1_Init 2 */
}

void MPSTM_OnMeasurementTimer()
{
	float array1[24] = { 0 };
	float array2[24] = { 0 };
	float array1_filt_data[24] = { 0 };
	float array2_filt_data[24] = { 0 };
	float complex_component = 0;
	uint16_t j = 0,k = 0;

	complex_component = compute_complex_signal();

		if (sample_count % 2 == 0)
		{
			for ( j = 0; j < TOTAL_ELECTROD_COUNT ; j++)
			{
				array1[j] = complex_component ;
			}

				//Triggere filter
				MilliVoltConv(array1 , 24);
				filter(array1,array1_filt_data,24);
				MPSTM_load_buff(array1_filt_data);
		}
		else if(sample_count % 2 != 0)
		{
			for (k = 0; k < TOTAL_ELECTROD_COUNT ; k++)
			{
				array2[k] = complex_component ;
			}
			{
				// Trigger filter
				MilliVoltConv(array2 , 24);
				filter(array2,array2_filt_data,24);
				MPSTM_load_buff(array2_filt_data);
				//MPLSMeasurement_compute_rms_value(array2_filt_data,array2_rms_value,freq_50);
			}
		}

		sample_count++;

}

float compute_complex_signal()
{
	float sin_comp_10hz = 0;
	float sin_comp_50hz = 0;
	float sin_comp_30hz = 0;
	float sin_comp_5hz = 0;
	float sin_comp_500hz = 0;
	float sin_comp_200hz = 0;
	float complex_component = 0;

	//sin_comp_10hz = AMPLITUDE*sin(DELTA*10*sample_count);
	//sin_comp_50hz = (AMPLITUDE/2)*sin(DELTA*50*sample_count);
/*	sin_comp_30hz = (AMPLITUDE/4)*sin(DELTA*30*sample_count);
	sin_comp_5hz  = AMPLITUDE*sin(DELTA*5*sample_count);
	sin_comp_500hz  = AMPLITUDE*2*sin(DELTA*500*sample_count);
	sin_comp_200hz  = AMPLITUDE*2*sin(DELTA*400*sample_count);*/
    if(sample_count<10) sin_comp_10hz=AMPLITUDE;
    if(sample_count>900)sample_count=0;
	complex_component = (sin_comp_10hz + sin_comp_50hz + sin_comp_30hz +
							sin_comp_5hz+sin_comp_500hz + sin_comp_200hz);
	return complex_component;
}

void filter(float raw_input[],float filter_output[],int num_samples)
{

	HighPassFilter(raw_input, filter_output,num_samples);
	//Averaging
	//Averaging(filter_output, filter_output,0xFFFFFF,num_samples);
	//Comb filter
	CombFilter(filter_output, filter_output,num_samples);

}

void MilliVoltConv(float input_data[],uint8_t sample_count)
{
	float converted_value = 0;

	for( int i = 0 ; i < sample_count ; i++)
	{
		converted_value = input_data[i] * mvConvFact;
		input_data[i] = converted_value;
	}

}

void MPSTM_load_buff(float filter_array[24])
{
		if(FillBufStatus == FILLFISTBUF)
		{
			for(int i = 0 ; i < 24 ; i++)
			{
				wind_array1[i][aryIndex] = filter_array[i]*filter_array[i];
			}
		}

		else if(FillBufStatus == FILLSECONDBUF)
		{
			for(int i = 0 ; i < 24 ;i++ )
			{
				wind_array2[i][aryIndex] = filter_array[i]*filter_array[i];
			}
		}
		aryIndex++;

		if(aryIndex == WINDOW_SIZE)
		{

			//check the buff status and change to next buff to fill

			if(FillBufStatus == FILLFISTBUF )
			{
				FillBufStatus = FILLSECONDBUF;
				PocessBufStatus = PROCESSFISBUF;
				aryIndex = 0;
			}
			else if(FillBufStatus == FILLSECONDBUF)
			{
				FillBufStatus = FILLFISTBUF;
				PocessBufStatus = PROCESSSECBUF;
				aryIndex = 0;
			}
			//check the buff status and set the flag to process the buff
		/*	if(FillBufStatus == FILLSECONDBUF )
			{
				PocessBufStatus = PROCESSSECBUF;
				//PocessBufStatus = PROCESSFISBUF;
				aryIndex = 0;
			}
			else if(FillBufStatus == FILLFISTBUF )
			{
				PocessBufStatus = PROCESSSECBUF;
				aryIndex = 0;
			}
			*/
		}
}


void MPLSComputeSendRMSValue(bool freq_type,int8_t buff_status)
{
	calculate_rms_value(freq_type,array_rms_value,buff_status);
	//MPCP_SendRespMeasurementProgress(1,2,3);
}
