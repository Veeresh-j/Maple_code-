#ifndef __MPLSMapleMaain_H
#define __MPLSMapleMaain_H
#include <string.h>
#include "main.h"
#include "stm32g4xx_hal.h"
#include "MPLSStimulation.h"
#include "MPLSMeasurement.h"
#include "MPLMCommandProcessor.h"

#define ADC_READ_ISTIM_LSADC 		ADC_CHANNEL_1
#define ADC_READ_ISTIM_HSADC 		ADC_CHANNEL_2
#define ADC_READ_VREF  				ADC_CHANNEL_9
#define ADC_READ_VSTIM_HS 			ADC_CHANNEL_13

bool MPSM_ReqReadRefVolt(void);
bool MPSM_ReadADC1(int chan);
void MPSM_OnReadRefVolt(uint32_t adcValue);

#endif
