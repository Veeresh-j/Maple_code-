/* Includes ------------------------------------------------------------------*/
#include "MPLSMapleMain.h"
//#include "MPLSMeasurement.h"
/*Private Includes---------------*/


/*define---------------------*/
#define BUFFERSIZE 256
#ifdef MODE_DEBUG
char uartAckbuf[50];
#endif


/* Private variables ---------------------------------------------------------*/ 
extern int counterPeriod;
//extern uint8_t win1_indx;
//extern uint8_t win2_indx;
extern int8_t PocessBufStatus;

extern DAC_HandleTypeDef hdac1;
extern DMA_HandleTypeDef hdma_dac1;
extern TIM_HandleTypeDef htim1;
extern UART_HandleTypeDef huart1;
extern ADC_HandleTypeDef hadc1;
extern struct CommandQEntry commandInQueCurrentlyProcessing;
extern struct CommandQEntry commandOutQueCurrentlyProcessing;
extern STIMULATION_TypeDef stimulationSettings;
/**************Global Variables *********/
int URT_Ptr = 0;
int refVoltI =0;
int adc_channel_requested =0;
uint8_t dac_signal[7]= {0,40,80,120,160,200,240};
uint8_t sp_buffer[3]={0x0F,0x0F,0x0F};
uint8_t p_rx_buffer;//[100];
uint8_t p_rx_buffer2;
char Rx_Data[BUFFERSIZE];
char Tx_Data[BUFFERSIZE];
char txdata[5] = "ok\r\n";
bool adc_busy = false;

//uint8_t dac_signal[2] = {0,255};
/* Private function prototypes -----------------------------------------------*/
//void STIM_HS_Shiftregister_Write(uint8_t *spiTxData,int datalength);
void UART_TX (void);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *uart);
void testStimulation(void);
void ProcessOUTQueueCommands(void);
void ProcessINQueueCommands(void);
void SendQuedRespMessages(void);
void ExecStimulationRequest(int queueIndex);
void DelayMillis(int millis);
void CheckUARTError(void);
void ClearUARTError(void);
void ClearUARTRecvd(void);

long int headerResetCounter =0;
long msTicks=0;
int deviceStatus;
extern int stimProgressTimer;

//TODO these values must be set to false in production version
bool batteryConnected = true;
int battoryStatus=2;
bool bateryFull = true;
int batteryPercent=50;
bool powerConnected=false;
bool bleConnected = true;
int keepAlive=0;
int recvReset=0;
bool disableKeepAlive=true;
/*------------------------------------------------------------------------------
 * Application main thread
 *----------------------------------------------------------------------------*/
void app_main (void)
{
	char welcome [] = "Welcome";
	__HAL_UART_ENABLE_IT(&huart1,UART_IT_RXNE);
	__HAL_UART_ENABLE_IT(&huart1,UART_IT_TC);
    HAL_UART_Receive_IT(&huart1,&p_rx_buffer,1);	  
		int returnCode = SysTick_Config(SystemCoreClock / 1000); 
	
		if (returnCode != 0)
		{                                   /* Check return code for errors */
			// Error Handling 
		}
	MPSTM_SwitchOffStimulationMode();
 	HAL_UART_Transmit(&huart1,(uint8_t*)welcome,strlen(welcome),10);
	MPCP_SendDeviceStatus();
	
	while(1)
	{
	//HAL_UART_Transmit(&huart4,(uint8_t*)welcome,strlen(welcome),10);
	//	 CheckUARTError();
		 //ClearUARTRecvd();
		if(headerResetCounter>5000)
		{
			MPCP_SendDeviceStatus();
			MPCP_ResetHeader();
			headerResetCounter=0;
			
		}
			//ClearUARTError();	
			
				if(recvReset>=3000)
				{
					recvReset=0;
					ClearUARTError();
				}
		if( HAL_UART_GetError(&huart1)!=0)
		{
			ClearUARTError();
		}
	
		if(PocessBufStatus == PROCESSFISBUF)
		{
			MPLSComputeSendRMSValue( freq_50);
			//MPCP_SendRespMeasurementProgress(10,20,30);
			PocessBufStatus = 0;
		}
		else if(PocessBufStatus == PROCESSSECBUF)
		{
			MPLSComputeSendRMSValue(freq_50);
			//MPCP_SendRespMeasurementProgress(6,5,6);
			PocessBufStatus = 0;
		}
		MPCP_ProcessINQueueCommands();
		MPCP_ProcessOUTQueueCommands();

	}
}
void ClearUARTRecvd()
{
	if(huart1.RxXferCount<huart1.RxXferSize)
	{
		//MPCP_CheckHeaderType(p_rx_buffer[0]);
	}
}

void ClearUARTError()
{
	 __HAL_UART_CLEAR_PEFLAG(&huart1);
	 __HAL_UART_CLEAR_FEFLAG(&huart1); 
	 __HAL_UART_CLEAR_NEFLAG(&huart1);
	 __HAL_UART_CLEAR_OREFLAG(&huart1);
	 __HAL_UART_CLEAR_TXFECF(&huart1);
	 __HAL_UART_CLEAR_FLAG(&huart1, UART_CLEAR_TXFECF);
	 __HAL_UART_CLEAR_FLAG(&huart1, UART_FLAG_RXFF);
	 __HAL_UART_CLEAR_FLAG(&huart1, UART_FLAG_RXFT);
	 __HAL_UART_RESET_HANDLE_STATE(&huart1);
	 HAL_UART_DeInit(&huart1);
	 HAL_UART_Init(&huart1);
	 HAL_UART_IRQHandler(&huart1);
	 HAL_UART_Receive_IT(&huart1,&p_rx_buffer,1);
}

void CheckUARTError()
{
	HAL_UART_StateTypeDef status;
	status = HAL_UART_GetState(&huart1);
	if(status == HAL_UART_STATE_ERROR)
	{
		ClearUARTError();
	}
}
void DelayMillis(int millis)
{
	msTicks = millis;
	long temp=msTicks;
	while(temp>0)
	{
		temp = msTicks;
	};
}
void SysTick_Handler_User(void)
{                               /* SysTick interrupt Handler. */
	++headerResetCounter;
	++keepAlive;
	++recvReset;
  if(msTicks>0) --msTicks;
	if(stimProgressTimer<1000) ++stimProgressTimer;
}

bool MPSM_ReadADC1(int chan)
{
	if(adc_busy) return false;
	HAL_ADC_Stop_IT(&hadc1);
	ADC_ChannelConfTypeDef sConfig = {0};
	sConfig.Channel = chan;
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
	adc_channel_requested=chan;
	adc_busy=true;
	HAL_ADC_Start_IT(&hadc1);
	return true;
}
bool MPSM_ReqReadRefVolt(void)
{
	return MPSM_ReadADC1(ADC_READ_VREF);
}

void MPSM_OnReadRefVolt(uint32_t adcValue)
{
	//float sv = ((float)adcValue/(float)STIM_ADC_MAXVAL)*(float)STIM_ADC_REF_VOLTAGE;
	refVoltI = adcValue;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(deviceStatus  == STATUS_DEVICE_STIM_RUNNING)
	{
		MPSTM_OnStimulationTimer();
	}
	else if(deviceStatus == STATUS_DEVICE_MESUREMENT_RUNNING)
	{
		MPSTM_OnMeasurementTimer();
	}
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* AdcHandle)
{
	uint32_t adcValue = HAL_ADC_GetValue(AdcHandle);
	
	adc_busy=false;

	switch(adc_channel_requested)
	{
		case ADC_READ_ISTIM_LSADC:
				 MPSTM_OnReadStimCurrentLS(adcValue);
				 break;
		case ADC_READ_ISTIM_HSADC:
				 MPSTM_OnReadStimCurrentHS(adcValue);
				 break;
		case ADC_READ_VSTIM_HS:
				 MPSTM_OnReadStimVoltHS(adcValue);
				 break;
		case ADC_READ_VREF:
				 MPSM_OnReadRefVolt(adcValue);
				 break;
	}
	
}


/*UART Tranmit function*/
void UART_TX (void)
{
	HAL_UART_Transmit(&huart1,(uint8_t*)Tx_Data,strlen(Tx_Data),10);
}

/* UART Receive Process bytes*/
void UART_Receive_process(void)
{
	memset(Tx_Data,0,256);
	int length = strlen(Rx_Data);
	strncpy(Tx_Data,Rx_Data,length);
	UART_TX();
	memset(Tx_Data,0,256);
	strncpy(Tx_Data,txdata,5);
	UART_TX();
}

int bufInUse=0;

/*UART Receive callback function*/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *uart)
{
	/*prevent unused argument(s) complication warning*/
	UNUSED(uart);
	recvReset=0;
	MPCP_CheckHeaderType(p_rx_buffer);

  if(uart->ErrorCode!=0)
	{
		__HAL_UART_RESET_HANDLE_STATE(uart);
			ClearUARTError();
	}
	 
	HAL_UART_Receive_IT(&huart1,&p_rx_buffer,1);
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
	if(huart->ErrorCode==HAL_UART_ERROR_ORE)
	{
		__HAL_UART_CLEAR_OREFLAG (huart);
	}
	__HAL_UART_RESET_HANDLE_STATE(huart);
	ClearUARTError();
}


/*void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim)
{
	 if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1){
		 MPSTM_OnStimulationTimer();
	}

}*/
