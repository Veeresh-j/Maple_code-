#include "MPLMCommandProcessor.h"
#include "MPLSStimulation.h"
#include "MPLSMeasurement.h"

#define BUFFERSIZE 256
#ifdef MODE_DEBUG
extern char uartAckbuf[BUFFERSIZE];
#endif

/*********************Extern Variables ********************************/
extern float stimCurrentLS;
extern float stimVoltageHS;
extern float stimCurrentHS;
extern int headerResetCounter;
extern int battoryStatus;
extern int batteryPercent;
extern int UVOVError;
extern int deviceStatus;
extern int keepAlive;
extern int refVoltI;
extern bool powerConnected;
extern bool bleConnected;
extern bool disableKeepAlive;
extern bool batteryConnected;
extern bool bateryFull;

extern STIMULATION_TypeDef stimulationSettings;
extern MEASUREMENT_TypeDef measurementSettings;

extern UART_HandleTypeDef huart1;

/************Global Variables ******/
int recvHeaderPtr = 0;
int recvBodyPtr = 0;
int headInQ = 0, tailInQ = 0;
int headInQOut = 0, tailInQOut = 0;
int curAllocatedQueElemForInQ;
int curAllocatedQueElemForOutQ;
unsigned char * commandBody;
char commandBuf[GEN_SMALL_BUF_SIZE*2];
bool inUseQ = false;
bool enableStimProgressMesg = true;
bool inUseQOut = false;
bool flagMapleHeaderRecvd = false;;
bool flagSimpleHeaderRecvd = false;;

/*************Structure Instances **********/
struct CommandQEntry commandQueue[SIZE_OF_CMD_QUEUE];
struct CommandQEntry commandInQueCurrentlyProcessing;
struct CommandQEntry commandOutQueCurrentlyProcessing;
struct CommandQEntry commandQueueOut[SIZE_OF_CMD_QUEUE];
struct Header head;

void MPCP_ResetHeader()
{
	flagMapleHeaderRecvd=false;
	flagSimpleHeaderRecvd=false;
	recvHeaderPtr=0;
	recvBodyPtr=0;
}
/*
This function is to be executed from the main loop to process
any Queued commands.
*/
void MPCP_ProcessINQueueCommands(void)
{
//	WAIT_FOR_INQ_ACCESS;
//	SET_INQ_INUSE;
	if((headInQ==tailInQ)||(commandQueue[tailInQ].status != STATUS_QUEELEM_READY))
	{
//		SET_INQ_FREE;
		return;
	}
  commandInQueCurrentlyProcessing = commandQueue[tailInQ];
	++tailInQ;
	if(tailInQ>= SIZE_OF_CMD_QUEUE)
	{
		tailInQ=0;
	}

//	SET_INQ_FREE;
	keepAlive=0;
	switch(commandInQueCurrentlyProcessing.command)
	{
		case CMD_REQ_KEEP_ALIVE:
			keepAlive=0;
			break;
		case CMD_REQ_SERVER_DISCOVERY:
			MPCP_SendRespServerDiscovery();
			break;
		case CMD_REQ_STIMULATION_START:
			MPSTM_ExecStimulationRequest();
		//MPCP_SendRespStimulationStartReq(STATUS_STIMREQ_OK);
			break;
		case CMD_REQ_STIMULATION_STOP:
			MPSTM_StopStimulation(STATUS_STIMREQ_OK);
			break;
		case CMD_REQ_INFO_VERSION:
			MPCP_SendReqInfoVersion();
			break;
		case CMD_REQ_INFO_BATTERY:
			MPCP_SendInfoBattery();
			break;
		case CMD_REQ_POWER_CHANGE:
			MPCP_ProcessPowerChange();
			break;
		case CMD_BLE_PROC_BATTERY_STAT:
			MPCP_ProcessBatteryStaus();
			break;
		case CMD_BLE_PROC_POWERCON_STAT:
			MPCP_ProcessPowerConStaus();
			break;
		case CMD_BLE_PROC_BTCON_STAT:
			MPCP_ProcessBLEStaus();
			break;
		case CMD_BLE_PROC_VSTIM_ERROR:
			MPCP_ProcessVSTIMError();
			break;
		case CMD_REQ_SET_KEEP_ALIVE_CHECK:
			MPCP_ProcessKeepAliveRequest();

			break;
		case CMD_REQ_MEASUREMENT_START:
			MPSTM_ExecMeasurementRequest();

			break;
		case CMD_REQ_MEASUREMENT_STOP:
			MPSTM_StopMeasurement();

			break;
		default:
			MPCP_ProcessDebugCommands();
		  break;
			
	}
	commandQueue[tailInQ].status = STATUS_QUEELEM_FREE;
//  if((cmd.commandBody!=NULL)&&(cmd.commandBody!=cmd.commandBodySmall)) free(cmd.commandBody);
}

void MPCP_ProcessOUTQueueCommands()
{
	//WAIT_FOR_OUTQ_ACCESS;
	//SET_OUTQ_INUSE;
	if(headInQOut==tailInQOut)
	{
		SET_OUTQ_FREE;
		return;
	}
	//todo may be not needed this extra struct instance , just used to avoid any concurrency problem
	commandOutQueCurrentlyProcessing = commandQueueOut[tailInQOut];
	++tailInQOut;
	if(tailInQOut>= SIZE_OF_CMD_QUEUE)
	{
		tailInQOut=0;
	}
	//SET_OUTQ_FREE;
	switch(commandOutQueCurrentlyProcessing.command)
	{
		case CMD_RESP_SERVER_DISCOVERY:
		case CMD_RESP_STIMULATION_START:
		case CMD_RESP_STIMULATION_POWER_CHANGE:
		case CMD_RESP_STIMULATION_PROGRESS:

		default:
			MPCP_SendQuedRespMessages();
			commandQueueOut[tailInQOut].status = STATUS_QUEELEM_FREE;
			break;
	}
  //if(cmd.commandBody!=NULL) free(cmd.commandBody);
}

void MPCP_SendQuedRespMessages()
{
	
#ifdef MODE_DEBUG
	memset(uartAckbuf,0,BUFFERSIZE);
	if(strlen((char *)commandOutQueCurrentlyProcessing.commandBodySmall)>0)
			sprintf(uartAckbuf,"\r%d#%s\n",(int)commandOutQueCurrentlyProcessing.command,commandOutQueCurrentlyProcessing.commandBodySmall);
	else 
		  sprintf(uartAckbuf,"\r%d\n",(int)commandOutQueCurrentlyProcessing.command);
	if((commandOutQueCurrentlyProcessing.command>=300)&&(commandOutQueCurrentlyProcessing.command<=400))
	{
		uartAckbuf[0] = CMD_TO_BLE_PREFIX;
	}else {
		uartAckbuf[0] = CMD_TO_APP_PREFIX; //added just for readability
	}
	 HAL_StatusTypeDef status = HAL_UART_Transmit(&huart1,(uint8_t*)uartAckbuf,strlen(uartAckbuf),50);
	 if (status != HAL_OK) {
        // TODO really need a HardwareError object, or something
        __HAL_UART_RESET_HANDLE_STATE(&huart1);
				if (HAL_UART_Init(&huart1) != HAL_OK)
				{
					Error_Handler();
				}
    }
#endif
#ifndef MODE_DEBUG
	struct Header head;
	head.prefix =  CMDP_PREFIX;
	head.length =  MPCP_EncodeInt32MSB(commandOutQueCurrentlyProcessing.length);
	head.command = MPCP_EncodeInt32MSB(commandOutQueCurrentlyProcessing.command);
	HAL_UART_Transmit(&huart1,(uint8_t*)&head,sizeof(head),10);
	HAL_UART_Transmit(&huart1,(uint8_t*)commandOutQueCurrentlyProcessing.commandBodySmall,strlen((char *)commandOutQueCurrentlyProcessing.commandBodySmall),10);
#endif
}
//Ascci debug command temp buffer

//Todo: Need to enhance to make sure priority commands will execute
//realtime. 
int MPCP_AllocateInQueueElement()
{
	  int allocatedElem;
		//WAIT_FOR_INQ_ACCESS;
		//SET_INQ_INUSE;
			if(headInQ<SIZE_OF_CMD_QUEUE)
			{
				allocatedElem=headInQ;
				commandQueue[headInQ].status = STATUS_QUEELEM_ALLOCATED;
				++headInQ;
				if(headInQ>=SIZE_OF_CMD_QUEUE) headInQ=0;
			}
		//SET_INQ_FREE;
		return allocatedElem;
}

int MPCP_AllocateOutQueueElement()
{   int allocatedElem;
	//	WAIT_FOR_OUTQ_ACCESS;
	//	SET_OUTQ_INUSE;
			if(headInQ<SIZE_OF_CMD_QUEUE)
			{
				allocatedElem = headInQOut;
				commandQueueOut[headInQOut].status = STATUS_QUEELEM_ALLOCATED;
				++headInQOut;
				if(headInQOut>=SIZE_OF_CMD_QUEUE) headInQOut = 0;
			}
	//	SET_OUTQ_FREE;
		return allocatedElem;
}

void MPCP_ParseNQueCMD(void)
{
	char * tok = NULL;
	char delim[] = "#";
	int len=0;
				
	tok = strtok((char*)commandBuf,delim);
	commandQueue[curAllocatedQueElemForInQ].command = atoi(tok);
	len = strlen(tok);
	strcpy((char *)commandQueue[curAllocatedQueElemForInQ].commandBodySmall,&commandBuf[len+1]);
	memset(commandBuf,0,GEN_SMALL_BUF_SIZE*2);
	recvHeaderPtr = 0;
	flagSimpleHeaderRecvd = 0;
	recvBodyPtr = 0;
	if(commandQueue[curAllocatedQueElemForInQ].status == STATUS_QUEELEM_ALLOCATED)
		commandQueue[curAllocatedQueElemForInQ].status = STATUS_QUEELEM_READY;
}

void MPCP_CheckHeaderType(unsigned char readByte)
{
	if(flagSimpleHeaderRecvd) 	
	{
		MPCP_ReceiveSimpleCMD(readByte);
		return;
	}
	if(flagMapleHeaderRecvd) 
	{
		MPCP_ReceiveMapleCMD(readByte);
		return;
	}
	MPCP_ReceiveSimpleCMD(readByte);
	if(!flagSimpleHeaderRecvd)
	{
		MPCP_ReceiveMapleCMD(readByte);
	}
}

void MPCP_ReceiveSimpleCMD(unsigned char readByte)
{
	//unsigned char * headerPtr = (unsigned char *) &head;
	if(!flagSimpleHeaderRecvd)
	{
		if(readByte == 0x0d) 
		{
			flagSimpleHeaderRecvd= true;
			curAllocatedQueElemForInQ = MPCP_AllocateInQueueElement();
			memset(commandQueue[curAllocatedQueElemForInQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
			
			recvBodyPtr = 0;
		}
	} 
	else 
	{
		if(readByte!='$')
		{
			if(readByte!=0x0a)
			{
				commandBuf[recvBodyPtr] = readByte;
				++recvBodyPtr;
			}
		}
		else
		{
				MPCP_ParseNQueCMD();
		}
	}
}
void MPCP_ReceiveMapleCMD(unsigned char readByte)
{
	headerResetCounter = 0;
	unsigned char * headerPtr = (unsigned char *) &head;
	
	if(!flagMapleHeaderRecvd)
	{
			headerPtr[recvHeaderPtr] = readByte;
			++recvHeaderPtr;
			if(recvHeaderPtr == 4)
			{
				if(head.prefix != CMDP_PREFIX)
				{
					recvHeaderPtr = 0;
				}
			}
			if(recvHeaderPtr == sizeof(head))
			{
				head.length = MPCP_DecodeInt32((char *) &head.length);
				head.command = MPCP_DecodeInt32((char *) &head.command);
			
				curAllocatedQueElemForInQ = MPCP_AllocateInQueueElement();
				commandQueue[curAllocatedQueElemForInQ].command = head.command;
				commandQueue[curAllocatedQueElemForInQ].length = head.length;
				if(head.length<GEN_SMALL_BUF_SIZE) 
				{
					memset(commandQueue[curAllocatedQueElemForInQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
					commandBody = commandQueue[curAllocatedQueElemForInQ].commandBodySmall;
				}
				else 
					commandBody = (unsigned char *) malloc(head.length);
				//TODO handle malloc error take proper action
				flagMapleHeaderRecvd = true;
				recvBodyPtr = 0;
			}
	}
	else
	{
		if(recvBodyPtr<head.length)
		{
			if(readByte!=0x0a) {
			commandBody[recvBodyPtr] = readByte;
			recvBodyPtr++;
			}
		}
		if(recvBodyPtr >= head.length)
		{
			recvHeaderPtr = 0;
			flagMapleHeaderRecvd = 0;
			recvBodyPtr = 0;
			if(commandQueue[curAllocatedQueElemForInQ].status == STATUS_QUEELEM_ALLOCATED)
				commandQueue[curAllocatedQueElemForInQ].status = STATUS_QUEELEM_READY;
		}
	}
}


unsigned long MPCP_DecodeInt32(char * buf)
{
    unsigned long val = (unsigned long)(buf[0] << 24);
    val = val + (unsigned long)(buf[1] << 16);
    val = val + (unsigned long)(buf[2] << 8);
    val = val + (unsigned long)(buf[3]);
    return val;
}

unsigned long MPCP_EncodeInt32MSB( unsigned long value)
{
	unsigned long converted;
	char * scratch;
	scratch = (char *) &converted;
	scratch[0] = (char)(value >> 24 & 0xFF);
	scratch[1] = (char)(value >> 16 & 0xFF);
	scratch[2] = (char)(value >> 8 & 0xFF);
	scratch[3] = (char)(value & 0xFF);
	return converted;
}

void MPCP_SendRespGeneral(int cmd,char *params)
{
  //TODO server discovery string to construct from MAC and other parameters
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();

	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = cmd;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%s",params);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
	
}

//<CR><CMD>#<MAC>,<Status><FirmwareVer>,<ServeName>,<HardwareVer>$
void MPCP_SendRespServerDiscovery()
{
  //TODO server discovery string to construct from MAC and other parameters
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_SERVER_DISCOVERY;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%s,%d,%s,%s,%s",SYSTEM_MAC,1,SYSTEM_FIRMWARE_VER,SYSTEM_DEVICE_NAME,SYSTEM_HARDWARE_VER);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
		
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
	
}

void MPCP_SendRespStimulationStartReq(int status)
{
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_STIMULATION_START;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%d",status);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
}


void MPCP_SendRespStimulationStopReq(int status)
{
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_STIMULATION_STOP;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%d",status);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
		
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
}

void MPCP_SendRespStimulationPowerChangeReq(int status,float current)
{
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_STIMULATION_POWER_CHANGE;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%d,%f",status,current);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
		
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
}

//CMD -<CMD>-<PendCycles>,<StimState>,<SetStimCurrent>,<MeasuredStimVoltage>,<MeasuredStimCurrent>,<batPercent>
//
//StimState :
//state 1 - Fade IN Start
//state 2 - Hold Start
//state 3 - Fade Out-Start
//state 4 - Delay
//state 5 - Cycle Completed
//SetStimCurrent : DAC value for current control
//MeasuredStimVoltage : Stimulation Volage measured using ADC
//MeasuredStimCurrent : Stimulation current measured

void MPCP_SendRespStimulationProgress(int numCyclesPending,int state,int currentValue)
{
	if(!enableStimProgressMesg) return;
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_STIMULATION_PROGRESS;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%d,%d,%d,%0.1f,%0.1f,%d\r\n",numCyclesPending,state,currentValue,stimVoltageHS,stimCurrentLS,batteryPercent);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
		
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;

}

void MPCP_SendReqInfoVersion()
{
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_INFO_VERSION;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%s",RESP_FIRMWARE_VERSION);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
		
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
}

void MPCP_SendDeviceStatus()
{
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_DEV_STATUS;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%d,%d,%d",battoryStatus,batteryPercent,0);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);

	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
}

void MPCP_SendInfoBattery()
{
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_INFO_VERSION;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%d,%d,%d",battoryStatus,batteryPercent,0);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
		
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
}
void MPCP_ParseElectrodes(char *elecrodeConfig)
{
	int elecNum = 0;
	int index = 0,i = 0;
	unsigned char sourceElecs[3];
	unsigned char sinkElecs[3];
		for(index = 0 ; index < 3 ; ++index)
		{
			unsigned char bitMask1 = 0x01;
			unsigned char bitMask0 = 0xfe;
			for(i = 0 ; i < 8 ; ++i)
			{
				//off
				if(elecrodeConfig[elecNum] == '0')
				{
					sourceElecs[index]&= bitMask0;
					sinkElecs[index]&= bitMask0;
				}
				//source
				if(elecrodeConfig[elecNum] == 'I')
				{
					sourceElecs[index]|= bitMask1;
					sinkElecs[index]&= bitMask0;
				}
				//sink
				if(elecrodeConfig[elecNum] == 'O')
				{
					sourceElecs[index]&= bitMask0;
					sinkElecs[index]|= bitMask1;
				}
				bitMask1 <<= 1;
				bitMask1 &= 0xfe;
				
				bitMask0 <<= 1;
				bitMask0 |= 0x01;
				++elecNum;
			}
		}
	
		
	/*stimulationSettings.sourceElecs_HS[3]=0x8f; //enable 24,23,22 electrodes
	stimulationSettings.sourceElecs_HS[2]=0xff; //enable 24,23,22 electrodes
	stimulationSettings.sourceElecs_HS[1]=0xff; //enable 24,23,22 electrodes
	stimulationSettings.sourceElecs_HS[0]=0xff; //enable 24,23,22 electrodes
	stimulationSettings.sourceElecs_LS[0]= 0x00;
	stimulationSettings.sourceElecs_LS[1]= 0x08;
	stimulationSettings.sourceElecs_LS[2]= 0x05;
	
	
	stimulationSettings.sinkElecs_LS[0]=0x00;
	stimulationSettings.sinkElecs_LS[1]=0x00;
	stimulationSettings.sinkElecs_LS[2]=0x00;
	stimulationSettings.sinkElecs_HS[0]=0xff;
	stimulationSettings.sinkElecs_HS[1]=0xff;
	stimulationSettings.sinkElecs_HS[2]=0xff;
	stimulationSettings.sinkElecs_HS[3]=0xff;*/
		
	MPSTM_SourceSink_bufferload(sourceElecs,sinkElecs);
}
/*
FIED 								TYPE  VALUE				DESCRIPTION
channels 1 to 24 		 I 		0; I; O 		0 = off I = source O = sink 
currentSource    		 I 								ignored Setting is ignored. Only high current source is supported and stimulation always starts at 0.5 mA.
amplitude            FI 	0..0.6 			In mA. Start setting is at most 2% of max range. Resolution of 0.05 mA. 
frequencyStimulation I 		2�150 			In Hz 
timePulsePhase 			 I 		200�1000 		In �sec. 
cyclesHold 					 I 		1�16777215 	M (note: 30 minutes hold at 150Hz required) 
cyclesFade 					 I 		0�65535 		L 
cyclesDelay 				 I 		0�65535 		K 
sequenceCount 			 I 		0�65535 		N 
Example : O00I00O00I00O00I00O00I00,2,0.5,35,250,140,70,420,45 
*/

bool MPCP_ParseStimulationRequest()
{
	
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok;
	char delim[] = ",";
	
	tok = strtok((char*)stimStr,delim);
	if(tok == NULL) return false;
	MPCP_ParseElectrodes(tok);
	
	//Current source , Ignore
	tok = strtok(NULL,delim); 
	if(tok == NULL) return false;
	
	//Read current settings 
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	stimulationSettings.currentInMa = atof(tok);
	
	//Read stimulation frequency
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	stimulationSettings.pulseFrequency = atoi(tok);
	
	//Read timePulsePhase 
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	stimulationSettings.pulsePhase = atoi(tok);
	
	//Read cyclesHold 
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	stimulationSettings.cyclesHoldM = atoi(tok);
	
	//Read cyclesFade 
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	stimulationSettings.cyclesFadeL = atoi(tok);
	
	//Read cyclesDelay 
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	stimulationSettings.cyclesDelayK = atoi(tok);
	
	//Read cycles Sequence Count
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	stimulationSettings.seqCountN = atoi(tok);
	
	return true;
}
void testStimulation()
{
	stimulationSettings.currentInMa = 5;
	stimulationSettings.pulsePhase = 200;
	stimulationSettings.pulseFrequency = 150;
	stimulationSettings.seqCountN = 1000;
	stimulationSettings.cyclesFadeL = 5;
	stimulationSettings.cyclesHoldM = 500;
	stimulationSettings.cyclesDelayK = 500;
	//selected source electroded 24,23,22 
	stimulationSettings.sourceElecs_HS[3] = 0x8f; //enable 24,23,22 electrodes
	stimulationSettings.sourceElecs_HS[2] = 0xff; //enable 24,23,22 electrodes
	stimulationSettings.sourceElecs_HS[1] = 0xff; //enable 24,23,22 electrodes
	stimulationSettings.sourceElecs_HS[0] = 0xff; //enable 24,23,22 electrodes
	stimulationSettings.sourceElecs_LS[0] = 0x00;
	stimulationSettings.sourceElecs_LS[1] = 0x08;
	stimulationSettings.sourceElecs_LS[2] = 0x05;
	
	
	stimulationSettings.sinkElecs_LS[0] = 0x00;
	stimulationSettings.sinkElecs_LS[1] = 0x00;
	stimulationSettings.sinkElecs_LS[2] = 0x00;
	stimulationSettings.sinkElecs_HS[0] = 0xff;
	stimulationSettings.sinkElecs_HS[1] = 0xff;
	stimulationSettings.sinkElecs_HS[2] = 0xff;
	stimulationSettings.sinkElecs_HS[3] = 0xff;
	
	//selected sink electroded 4,3,2
	/*
	stimulationSettings.sinkElecs_LS[0]=0x00;
	stimulationSettings.sinkElecs_LS[1]=0x04;
	stimulationSettings.sinkElecs_LS[2]=0x88;
	stimulationSettings.sinkElecs_HS[0]=0xff;
	stimulationSettings.sinkElecs_HS[1]=0xff;
	stimulationSettings.sinkElecs_HS[2]=0xf8;
	stimulationSettings.sinkElecs_HS[3]=0xff;*/
	MPSTM_StartStimulation();
	
}

void MPCP_ProcessDebugCommands(void)
{
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok = NULL;
	char delim[] = ",";
	uint8_t elecs[4];
	float tempF;
	int tempI;
	char szResp[50];
	
	 tok = strtok((char*)stimStr,delim);
	
	switch(commandInQueCurrentlyProcessing.command)
	{
		case CMD_DEBUG_SHIFTREG_POWER:
			if(tok[0] == '1') MPSTM_PowerUpShiftReg(true);
			 else  MPSTM_PowerUpShiftReg(false);
			 break;
		case CMD_DEBUG_SHIFTREG_LOAD:
			 MPSTM_PowerUpShiftReg(true);
			 elecs[0] = atoi(tok);
			 tok = strtok(NULL,delim);
			 elecs[1] = atoi(tok);
			 tok = strtok(NULL,delim);
			 elecs[2] = atoi(tok);
			 tok = strtok(NULL,delim);
			 elecs[3] = atoi(tok);
			 tok = strtok(NULL,delim);
			 MPSTM_LoadShiftReg(elecs);
			 MPSTM_ShiftRegLatchLoad();
			 MPSTM_ShiftRegOutputEnable(true);
			 break;
		case CMD_DEBUG_SINK_ELEC_LOAD:
		   //<CR>413##DACVal,elec0,elec1,elec2,elec3
			HAL_GPIO_WritePin(EN_5V5_GPIO_Port,EN_5V5_Pin,GPIO_PIN_SET);
			MPSTM_DACEnable(true);
			tempI = atoi(tok);
			MPSTM_SetDACValue(tempI);
			tok = strtok(NULL,delim);
			elecs[0] = atoi(tok);
			tok = strtok(NULL,delim);
			elecs[1] = atoi(tok);
			tok = strtok(NULL,delim);
			elecs[2] = atoi(tok);
			tok = strtok(NULL,delim);
			// elecs[3] = atoi(tok);
			// tok = strtok((char*)stimStr,delim);

			 //GPIOD->ODR =  0xffffU;
			 //GPIOE->ODR |= 0xff00;
			 MPSTM_EnableSinkElectrodes(elecs);
			 break;
		case CMD_DEBUG_SINK_ELEC_RSET:
			   //<CR>413##DACVal,elec0,elec1,elec2,elec3
			MPSTM_DACEnable(false);
			MPSTM_SetDACValue(0);
			elecs[0] = 0;
			elecs[1] = 0;
			elecs[2] = 0;
			MPSTM_EnableSinkElectrodes(elecs);
			break;
		
		case CMD_DEBUG_VSTIM_VOLT_SET:				
			tempF = atof(tok);
			MPSTM_SetStimVoltage(tempF);
			MPCP_SendRespGeneral(CMD_DEBUG_VSTIM_VOLT_SET,tok);
			 break;
		case CMD_DEBUG_VSTIM_ONOFF:
			 if(tok[0] == '1') MPSTM_SwitchOnStimVoltage();
			 else MPSTM_SwitchOffStimVoltage();
			 break;
		case CMD_DEBUG_STIM_DAC_SET:
			MPSTM_DACEnable(true);
			tempI = atoi(tok);
			MPSTM_SetDACValue(tempI);
			if(tempI == 0) MPSTM_DACEnable(false);
			break;
		case CMD_DEBUG_STIM_PROG_MESG:
			 if(tok[0] == '1') enableStimProgressMesg = true;
			 else  enableStimProgressMesg =false;
			 break;
		case CMD_DEBUG_ISTIM_HS_ADC:
			 memset(szResp,0,50);
			 sprintf(szResp,"%f",stimCurrentHS);
			 MPCP_SendRespGeneral(CMD_DEBUG_ISTIM_HS_ADC,szResp);
			 MPSTM_ReqReadStimCurrentHS();
			 break;
		case CMD_DEBUG_ISTIM_LS_ADC:
			  memset(szResp,0,50);
			  sprintf(szResp,"%f",stimCurrentLS);
			  MPCP_SendRespGeneral(CMD_DEBUG_ISTIM_LS_ADC,szResp);
			  MPSTM_ReqReadStimCurrentLS();
			  break;
		case CMD_DEBUG_VSTIM_HS_ADC:
			  memset(szResp,0,50);
			  sprintf(szResp,"%f",stimVoltageHS);
			  MPCP_SendRespGeneral(CMD_DEBUG_VSTIM_HS_ADC,szResp);
			  MPSTM_ReqReadStimVoltHS();
			  break;
	  case CMD_DEBUG_VREF:
			   memset(szResp,0,50);
			   sprintf(szResp,"%d",refVoltI);
			   MPCP_SendRespGeneral(CMD_DEBUG_VREF,szResp);
			// MPSTM_ReqReadStimVoltHS();
			   break;
	  case CMD_DEBUG_LED:
			   HAL_GPIO_TogglePin(STM_nLED_GPIO_Port,STM_nLED_Pin);
			   sprintf(szResp,"%d",0);
			   MPCP_SendRespGeneral(CMD_DEBUG_LED,szResp);
			   break;
		case CMD_DEBUG_STIMMODE_OFF:
				MPSTM_SwitchOffStimulationMode();
				sprintf(szResp,"%d",0);
				MPCP_SendRespGeneral(CMD_DEBUG_STIMMODE_OFF,szResp);
				break;
		case CMD_DEBUG_SINK_TEST_STIM:
			   testStimulation();
			   	   break;
		
	}
}
/*
0 = ok
-30 = battery empty (= 5%)
-31 = connected to mains (measurement or
stimulation is not allowed when the Maple
instrument is connected to mains)
-32 = invalid current increase (more than 1mA)
-33 = max current reached (either more than 30 or 1
of the constraints is violated).
*/
void MPCP_ProcessPowerChange()
{
	double currentVal = 0;
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok=NULL;
	char delim[] = ",";

	
	tok = strtok((char*)stimStr,delim);
	currentVal = atof(tok);
	if(deviceStatus==STATUS_DEVICE_STIM_RUNNING)
	{
		if(currentVal <= MAX_STIM_CURRENT)
		{
			stimulationSettings.currentInMa = currentVal;
			MPSTM_CalcDACDeltaValue();
			MPCP_SendRespStimulationPowerChangeReq(STATUS_STIMREQ_OK,currentVal);
		}
		else 
		{
			MPCP_SendRespStimulationPowerChangeReq(STATUS_STIMREQ_MAX_CURRENT,stimulationSettings.currentInMa);
		}
	}
	else
	{
		MPCP_SendRespStimulationPowerChangeReq(STATUS_STIMREQ_STIM_NOT_RUNNING,0);
	}
	
}
void MPCP_SendResMasterSlaveCommands(int command, int status)
{
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();
	
	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_BLE_PROC_ACK;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%d,%d",command,status);
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);
		
	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;
}
void MPCP_ProcessKeepAliveRequest()
{
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok;
	char delim[] = ",";
	int status;
	//int cycle;
	
	tok = strtok((char*)stimStr,delim);
	status = atoi(tok);
	
	if(status == 0)
	{ 
		disableKeepAlive = false;
	}
	else
	{
		disableKeepAlive = true;
	} 
}
/*Status update from BLE processor

200-status,percentage,recharge count
Status : 0-not connected, 1 charging, 2- batfull

*/
void MPCP_ProcessBatteryStaus()
{
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok = NULL;
	char delim[] = ",";
	int status = 0; //Initialized to zero
	int cycle = 0; //
	
	tok = strtok((char*)stimStr,delim);
	battoryStatus = atoi(tok);
	
	tok = strtok((char*)stimStr,delim);
	batteryPercent = atoi(tok);
	
	tok = strtok((char*)stimStr,delim);
	cycle = atoi(tok);
	
	if(battoryStatus == 0)
	{ 
		batteryConnected = false;
	}
	else if (status == 1)
	{
		batteryConnected = true;
		bateryFull = false;
	}
	else if (status == 1)
	{
		batteryConnected = true;
		bateryFull = true;
	}
	MPCP_SendResMasterSlaveCommands(CMD_BLE_PROC_BATTERY_STAT, 1);
}
/*Status update from BLE processor
201-status
Status:- 1 -connected,0- removed
*/
void MPCP_ProcessPowerConStaus(void)
{
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok = NULL;
	char delim[] = ",";
	int status;
	//int cycle;
	
	tok = strtok((char*)stimStr,delim);
	status = atoi(tok);
	
	if(status == 0)
	{ 
		powerConnected = false;
	} else 
	{
		batteryConnected = true;
	} 
	MPCP_SendResMasterSlaveCommands(CMD_BLE_PROC_POWERCON_STAT, 1);
}
/*
203-Status
Status : 0- Disconnected 1- Connected

*/
void MPCP_ProcessBLEStaus(void)
{
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok;
	char delim[] = ",";
	int status;
	//int cycle;
	
	tok = strtok((char*)stimStr,delim);
	status = atoi(tok);
	
	if(status == 0)
	{ 
		bleConnected = false;
	}
	else
	{
		bleConnected = true;
	} 
	MPCP_SendResMasterSlaveCommands(CMD_BLE_PROC_VSTIM_ERROR, 1);
}
/*
202-ERROR 
ERROR - 1 Over Voltage 2 - Under Voltage 3- Over Current 4- Unknown error
*/
void MPCP_ProcessVSTIMError(void)
{
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok;
	char delim[] = ",";
	int status;
	//int cycle;
	
	tok = strtok((char*)stimStr,delim);
	status = atoi(tok);
	
	UVOVError = status;
	MPCP_SendResMasterSlaveCommands(CMD_BLE_PROC_BTCON_STAT, 1);
}

void MPCP_SendCmdHeader(struct Header  * head)
{
}
void MPCP_SendCmdBody(char *body, int len)
{
	
}

bool MPCP_ParseMeasurementRequest()
{
	unsigned char * stimStr = commandInQueCurrentlyProcessing.commandBodySmall;
	char * tok;
	char delim[] = ",";

	tok = strtok((char*)stimStr,delim);
	if(tok == NULL) return false;
//	MPCP_ParseElectrodes(tok);

	//Sample rate , Ignore
	tok = strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.samplerate = atof(tok);

	//Read max_time sec
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.maxtime = atof(tok);

	//Read measurement type
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.measurement_type = atoi(tok);

	//Read ref group
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.ref_group = atoi(tok);

	//Read measured values
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.cmpr_ref_group = atoi(tok);

	//Read output sample rate
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.output_samplerate = atoi(tok);

	//Read initialization time
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.initial_time = atoi(tok);

	//Read active time
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.active_time = atoi(tok);

	//Read rest time
	tok =  strtok(NULL,delim);
	if(tok == NULL) return false;
	measurementSettings.rest_time = atoi(tok);

	return true;
}



//	Measurement response
void MPCP_SendRespMeasurementProgress(int numCyclesPending,int state,int currentValue)
{
	if(!enableStimProgressMesg) return;
	curAllocatedQueElemForOutQ = MPCP_AllocateOutQueueElement();

	memset(commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,0,GEN_SMALL_BUF_SIZE);
	commandQueueOut[curAllocatedQueElemForOutQ].command = CMD_RESP_MEAUREMENT_PROGRESS_RMS;
	sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%d,%d",numCyclesPending,state);
	for(int i=0;i<2;++i){
		sprintf((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,"%s,%4.1f",commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall,array_rms_value[i]);
	}
	commandQueueOut[curAllocatedQueElemForOutQ].length = strlen((char *)commandQueueOut[curAllocatedQueElemForOutQ].commandBodySmall);

	commandQueueOut[curAllocatedQueElemForOutQ].status = STATUS_QUEELEM_READY;

}
