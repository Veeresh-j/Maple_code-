
/**
  ******************************************************************************
  * @file           : MPLSStimulation.h
  * @brief          : Stimulation header file
  ******************************************************************************
  * @auther : iOrbit
  *
  ******************************************************************************
  */
	
#ifndef __MPLMCommandProcessor_H
#define __MPLMCommandProcessor_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "stm32g4xx_hal.h"


#define CMDP_PREFIX  						0xffffffff
#define SIZE_OF_CMD_QUEUE					5
#define MAX_STIM_CURRENT 					30.0
#define SYSTEM_MAC 							"00:00:00:a1:2b:cc"
#define SYSTEM_FIRMWARE_VER 				"1.0.0"
#define SYSTEM_HARDWARE_VER 				"1.0" //Rev 1.0
#define SYSTEM_DEVICE_NAME  				"MapleHome-1" //This will be modified later to store through comannd -in flash
#define RESP_SERVER_DISCOVERY 				"00:00:00:a1:2b:cc,0,3.0.3,MPFTest,6"
#define RESP_FIRMWARE_VERSION 				"1.0"

#define CMD_RESP_DEV_STATUS	 				0
#define CMD_RESP_SERVER_DISCOVERY			9052
#define CMD_RESP_STIMULATION_START 			960
#define CMD_RESP_STIMULATION_STOP 			961
#define CMD_RESP_STIMULATION_POWER_CHANGE 	963
#define CMD_RESP_STIMULATION_PROGRESS 		962
#define CMD_RESP_MEAUREMENT_PROGRESS_RMS	953
#define CMD_RESP_INFO_VERSION  				920 // String version
#define CMD_RESP_SERVER_PING  				910
#define CMD_RESP_INFO_BATTERY  				921  //<BATCONNECTED>,<PERCENT>,<CYCLE>
#define CMD_RESP_POWER_CHANGE  				963   //<STATUS>,<AMPL>

#define CMD_BLE_PROC_ACK 					200
#define CMD_BLE_PROC_BATTERY_STAT 			201
#define CMD_BLE_PROC_POWERCON_STAT 			202
#define CMD_BLE_PROC_VSTIM_ERROR  			203
#define CMD_BLE_PROC_BTCON_STAT  			204
#define CMD_TO_BLE_PREFIX 					27
#define CMD_TO_APP_PREFIX 					13
#define CMD_TO_BLE_VSTIM_ON 				301
#define CMD_TO_BLE_ACK 						300 //ack for commands recived from BLE
#define CMD_TO_READ_ISTIM_DAC 				303

#define CMD_REQ_KEEP_ALIVE 					0
#define CMD_REQ_SERVER_DISCOVERY 			5
#define CMD_REQ_STIMULATION_START 			60
#define CMD_REQ_STIMULATION_STOP 			61
#define CMD_REQ_INFO_VERSION  				20
#define CMD_REQ_INFO_BATTERY  				21
#define CMD_REQ_SERVER_PING 				10
#define CMD_REQ_POWER_CHANGE  				63 //
#define CMD_REQ_SET_KEEP_ALIVE_CHECK  		90 //
#define CMD_REQ_MEASUREMENT_START			50
#define CMD_REQ_MEASUREMENT_STOP			51

/*
Shift Reg Power Up
Shift Reg Load
Shift reg Out Enable Disable
VSTIM
VSTIM ONOFF
DAC set
Stop/Start Progress Mesg
Read ISTIM_HS ADC
Read ISTIM_LS-ADC
Read VSTIM_HSADC
Read Vref
*/
#define CMD_DEBUG_SHIFTREG_POWER 			400
#define CMD_DEBUG_SHIFTREG_LOAD 			401
#define CMD_DEBUG_VSTIM_VOLT_SET 			403
#define CMD_DEBUG_VSTIM_ONOFF 				404
#define CMD_DEBUG_STIM_DAC_SET 				405
#define CMD_DEBUG_STIM_PROG_MESG 			406
#define CMD_DEBUG_ISTIM_HS_ADC 				407
#define CMD_DEBUG_ISTIM_LS_ADC 				408
#define CMD_DEBUG_VSTIM_HS_ADC 				409
#define CMD_DEBUG_VREF 						410
#define CMD_DEBUG_LED 						411
#define CMD_DEBUG_STIMMODE_OFF 				412
#define CMD_DEBUG_SINK_ELEC_LOAD 			413
#define CMD_DEBUG_SINK_ELEC_RSET 			414
#define CMD_DEBUG_SINK_TEST_STIM 			415

#define STATUS_STIMREQ_OK 					 0
#define STATUS_STIMREQ_BATLOW 				-30
#define STATUS_STIMREQ_MAINS_CONNECTED 		-31
#define STATUS_STIMREQ_INVALID_CURRENT 		-32
#define STATUS_STIMREQ_MAX_CURRENT 			-33
#define STATUS_STIMREQ_PROBE_NOT_CONNECTED 	-34
#define STATUS_STIMREQ_LEAD_OF_DETECTION_FAILED -35
#define STATUS_STIMREQ_LOST_CON 			-36
#define STATUS_STIMREQ_STIM_NOT_RUNNING 	-37
#define STATUS_STIMREQ_APP_NOT_RESPONDING 	-38

#define STATUS_QUEELEM_FREE 				0
#define STATUS_QUEELEM_ALLOCATED 			1
#define STATUS_QUEELEM_READY 				2
#define STATUS_DEVICE_SLEEP 				0
#define STATUS_DEVICE_IDLE 					1
#define STATUS_DEVICE_STIM_RUNNING 			2
#define STATUS_DEVICE_MESUREMENT_RUNNING 	3


#define WAIT_FOR_INQ_ACCESS 				while(inUseQ)
#define WAIT_FOR_OUTQ_ACCESS 				while(inUseQOut)
#define SET_INQ_INUSE 						inUseQ = true
#define SET_INQ_FREE 						inUseQ = false
#define SET_OUTQ_INUSE 						inUseQOut = true
#define SET_OUTQ_FREE 						inUseQOut = false
#define GEN_SMALL_BUF_SIZE 					200
#define MODE_DEBUG 							1

struct Header 
{
  unsigned long prefix;
  unsigned long command;
  unsigned long length;
};

/*
Command received through communication link will be placed in a Queue.
Which is then processed by main loop. The structure defined below is
used to keep the command and command body in the queue.
It is Command Processors responsibility to release the memory allocated 
for the command body.
*/
struct CommandQEntry
{
	unsigned long command;
	unsigned long length;
	unsigned char *commandBody;
	unsigned char commandBodySmall[GEN_SMALL_BUF_SIZE]; //TODO Tried to use malloc , found that Keil C has some issues with malloc
																	//Arsh suggested to use atatic array
	unsigned int status;
};

extern struct CommandQEntry commandQueue[SIZE_OF_CMD_QUEUE];
extern struct CommandQEntry commandQueueOut[SIZE_OF_CMD_QUEUE];
extern struct CommandQEntry commandInQueCurrentlyProcessing;
extern struct CommandQEntry commandOutQueCurrentlyProcessing;
extern int headInQ, tailInQ;
extern bool inUseQ;
extern int headInQOut, tailInQOut;
extern bool inUseQOut;
extern struct Header head;
extern int recvHeaderPtr;
extern int recvBodyPtr;
extern bool flagHeaderRecvd;
extern unsigned char * commandBody;

/***************************************************/
//TODO can be removed from production code.
//Use #define to exclude from production code
void MPCP_CheckHeaderType(unsigned char readByte);
void MPCP_ParseNQueCMD(void);
void MPCP_ReceiveSimpleCMD(unsigned char readByte);

/*************************************************/
unsigned long MPCP_DecodeInt32(char * buf);
void MPCP_ReceiveMapleCMD(unsigned char readByte);
void MPCP_SendRespServerDiscovery(void);
void MPCP_SendCmdHeader(struct Header  * head);
void MPCP_SendCmdBody(char *body, int len);
bool MPCP_ParseStimulationRequest(void);
bool MPCP_ParseMeasurementRequest(void);
void MPCP_ParseElectrodes(char *elecrodeConfig);
void MPCP_ResetHeader(void);
void MPCP_SendRespGeneral(int cmd,char *params);
void MPCP_SendRespStimulationStartReq(int status);
void MPCP_SendRespStimulationStopReq(int status);
void MPCP_SendRespStimulationProgress(int numCyclesPending,int state,int currentValue);
void MPCP_SendRespStimulationPowerChangeReq(int status,float current);
void MPCP_SendQuedRespMessages(void);
int MPCP_AllocateInQueueElement(void);
int MPCP_AllocateOutQueueElement(void);
void MPCP_ProcessBatteryStaus(void);
void MPCP_ProcessPowerConStaus(void);
void MPCP_ProcessBLEStaus(void);
void MPCP_ProcessVSTIMError(void);
void MPCP_ProcessPowerChange(void);
void MPCP_ProcessKeepAliveRequest(void);
void MPCP_ReceiveMapleCMD(unsigned char readByte);
void MPCP_SendReqInfoVersion(void);
void MPCP_SendInfoBattery(void);
void MPCP_SendPowerChange(void);
void MPCP_SendDeviceStatus(void);
void MPCP_ProcessINQueueCommands(void);
void MPCP_ProcessOUTQueueCommands(void);
void MPCP_ProcessDebugCommands(void);


void MPCP_SendRespMeasurementProgress(int numCyclesPending,int state,int currentValue);

#ifdef __cplusplus
}
#endif

#endif /*__MPLMCommandProcessor_H */

