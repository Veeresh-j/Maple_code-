/*
 * FilterComb.h
 *
 *  Created on: 08-Jul-2020
 *      Author: ubuntu
 */

#ifndef FILTERCOMB_H_
#define FILTERCOMB_H_

#include <stdbool.h>
#include "utility.h"


void CombFilter(float input[], float output[],int samplecount);


#endif /* FILTERCOMB_H_ */
