/*
 * utility.h
 *
 *  Created on: 07-Jul-2020
 *      Author: ubuntu
 */

#ifndef UTILITY_H_
#define UTILITY_H_

#define MAXCHANNELS 	24

typedef enum
{
	HERTZ50,
	HERTZ60
}FREQUENCY;

#endif /* UTILITY_H_ */
