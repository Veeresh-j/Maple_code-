#include "MPLS_Rms.h"
#include "string.h"
#include "MPLSMeasurement.h"
#include "math.h"
typedef float WindowArray[24][100];
uint_64 isqrt1(uint_64 n, int max_iterations);
//long double isqrt1(long double n, int max_iterations);

//static const int max_iterations = 50;    // max iterations for isqrt. calculated that this is  the minimum for the given window size.
extern float wind_array1[24][100];
extern float wind_array2[24][100];
/* Newton's method for square root: x(i+1) = 1/2 * (x(i) + n/x(i))
 */
uint_64  isqrt1(uint_64 n, int max_iterations)
{
	uint_64 x0 = 1;
	uint_64 xi = 0;
	for (int i = 0; i < max_iterations; i++)
	{
		xi = ((n / x0) + x0) >> 1;
		x0 = xi;
	}
	return xi;
}
//void MPLSMeasurement_compute_rms_value(double* cin, double* cout, bool freq_60)
void calculate_rms_value(bool freq_60,double* cout,int buff_status)
{
	// limit number of multipliers
	//float *running_squares[MAXCHANNELS][100];
	int window_size;
	WindowArray *running_squares;

	if(freq_60)
	{
		window_size = 102;
	}
	else
	{
		window_size = 100;
	}

	//int index = 0;

	if (buff_status == PROCESSFISBUF)
	{
		//memcpy(running_squares,wind_array2,sizeof(running_squares));
		running_squares = wind_array1;
	}
	else if(buff_status == PROCESSSECBUF)
	{
		//memcpy(running_squares,wind_array2,sizeof(running_squares));
		running_squares = wind_array2;
	}
	long double rms_in_buff[24] = { 0 };
	//running squires

	for( int channel_id = 0; channel_id < MAXCHANNELS ;channel_id++)
	{
		rms_in_buff[channel_id]=0;
		for (int j = 0 ; j<window_size ; j++ )
		{
			//(*running_squares)[channel_id][j] *=(* running_squares)[channel_id][j];
			rms_in_buff[channel_id] += (*running_squares)[channel_id][j];
		}
		long double temp = rms_in_buff[channel_id] / window_size;
		cout[channel_id] = sqrt(temp);

	}

}



//void MPLSMeasurement_compute_rms_value(double* cin, double* cout, bool freq_60)
/*
void MPLSMeasurement_compute_rms_value(float* cin, double* cout, bool freq_60)
{

	// limit number of multipliers
	int window_size;

	if(freq_60)
	{
		window_size = 102;
	}
	else
	{
		window_size = 100;
	}

	int index = 0;
	long double running_squares[MAXCHANNELS][100] = { 0 };
	long double rms_in_buff[24] = { 0 };

	//loop 24


	for(int channel_id = 0;channel_id < MAXCHANNELS ; )
	{
		running_squares[channel_id][index] = cin[channel_id] * cin[channel_id];

		 channel_id++;
	}

	for(int i = 0; i < MAXCHANNELS ; i++) //i corresponds to channel id
	{
		for(int j = 0 ; j < window_size ; j++)// J corresponds to window size
		{
			rms_in_buff[i] = rms_in_buff[i] + running_squares[i][j];
		}
	}

	index++;
	if(index >= window_size )
	{
		index = 0;
	}

	for (int channel_id=0; channel_id<MAXCHANNELS; channel_id++)
	{
		long double temp = rms_in_buff[channel_id] / window_size;
	//	cout[channel_id] = isqrt1(temp, max_iterations);
		cout[channel_id] = sqrt(temp);

	}



	{
	running_squares[index][chanel]= cin[chanel]*cin[chanel]
		++index;
	if(index>=window_size )index=0;
	}
	for (int window_position = 0; window_position < window_size; window_position++)
	{

		for (int channel_id = 0; channel_id < MAXCHANNELS; channel_id++)
		{
			// calculate running squares
			double input_sample = cin[index];
			running_squares[channel_id] += input_sample * input_sample;
			index++;
		}
	}

	// calculate rms
}*/

