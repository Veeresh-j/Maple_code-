/**
  ******************************************************************************
  * @file           : MPLSMeasurement.h
  * @brief          : Measurement header file
  ******************************************************************************
  * @auther : iOrbit
  *
  ******************************************************************************
  */

#ifndef __MPLSMeasurement_H
#define __MPLSMeasurement_H
#include "main.h"
#include "stm32g4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>
#include "MPLSMeasurement.h"
#include "MPLMCommandProcessor.h"

/********************* Constants ******************************/

#define MEASUREMENT_SATUS_INIT 						0
#define AMPLITUDE									100 //IN mv
#define TOTAL_ELECTROD_COUNT						24
#define SIGNAL_FREQ									900 //
#define	PI											M_PI
#define DELTA										((2*PI)/SIGNAL_FREQ)
#define freq_50										false
#define FILLFISTBUF									0x01 // fill first buff
#define FILLSECONDBUF								0x02 // fill second buff
#define PROCESSFISBUF								0x01 //Process first buff
#define PROCESSSECBUF								0x02 //Process second buffer
#define WINDOW_SIZE									100
//#define freq_60										true //check error


typedef struct
{
	char channels[24]; //Channel settings recvd from app as string
	uint8_t sourceElecs_HS[4]; //32 bit length source electrode settings 0-ON 1- Off, used switch on HS FET during source on phase
	uint8_t sourceElecs_LS[3]; //24 bit length sink electrode used to switch off sink electrodes to toggle source to sink 1- FET ON 0 -FET Off
	uint8_t sinkElecs_LS[3]; //24 bit length sink electrode settings . Used during source phase to switch on sink electrodes.
	uint8_t sinkElecs_HS[4]; //32 bit length source electrode settings . Used during sink phase to switch on source electrodes.
	int samplerate;	// acquisition speed
	int maxtime;  //In seconds
	int measurement_type; //raw,rms ,contraction,
	int ref_group; //sel of ref group
	int cmpr_ref_group; // cmpr ref group
	int output_samplerate; //fixed to 10 hz
	int initial_time; //in sec
	int active_time; // contraction data only
	int rest_time;	//contraction data only
} MEASUREMENT_TypeDef;

uint8_t measurement_timer_status ;
bool MPSTM_ExecMeasurementRequest();
float compute_complex_signal();
void MPSTM_MeasurementTimerInit();
void MPSTM_StratMeasurement();
void MMPSTM_StopMeasurement();
void MPSTM_OnMeasurementTimer();
void MPSTM_load_buff(float filter_array[]);
void MPLSComputeSendRMSValue(bool freq_type);
//Filter section
void filter(float raw_input[],float filter_output[],int num_samples);
void MilliVoltConv(float input_data[],uint8_t sample_count);

#endif /*__MPLSStimulation_H*/
