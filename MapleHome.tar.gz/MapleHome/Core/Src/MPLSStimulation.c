/*Private Includes---------------*/
#include "MPLSMapleMain.h"
#include "MPLSStimulation.h"
#include "MPLMCommandProcessor.h"
#include "MPLSMapleMain.h"

/*define---------------------*/
extern SPI_HandleTypeDef hspi1;
extern DAC_HandleTypeDef hdac1;
extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim1;
extern UART_HandleTypeDef huart1;

/****Extern Variables *****/
extern int keepAlive;
extern int batteryPercent;
extern int deviceStatus;
extern bool batteryConnected;
extern bool bateryFull;
extern bool powerConnected;
extern bool bleConnected;
extern bool disableKeepAlive;

/*
During Onset and Offset DAC values increments in staircase form. 
This function calculates the value which is incremented in each 
step of OnSet and Offset. According to circuit a 100 MV set on the 
DAC pin will cause a current limit of 1 ma on sum of all electrodes.
Assume a value of X produce 1 mv output on DAC. 

VREF = 2.9
MaxDAC Value = 4096 (12 Bit DAC)//bijoy max dac value 4095
Value for 100mv (X) = (4096/2900)*100 = 141
Set Current = N ma
Limit Voltage = N*100
OnSetPulses = L
DACValueOnHOLD = N*100*X
DACDeltaValue = N*100*X/L

*/

/***********Global Variables *******/
float stimCurrentLS = 0.5;
float stimCurrentHS ;
float stimVoltageHS = 10.00;
float stimVoltSet = 10.00;
float clockPerod =(int) ((float)(1/(float)STIM_CLOCK_FREQUENCY)*1000000);
int dacValueFor1ma = ((float)STIM_DAC_MAXVAL/(float)STIM_DAC_VREF*1000)*100;
int pulseState;
int dacValueForSetCurrent=0;
int deltaDACStepValue;
int dacHoldValueForSetCurrent;
int dacCurValue;
int onsetStepCounter;
int offsetStepCounter;
int holdStateCounter;
int offStateCounter;
int sequenceCounter;
int pulsePhaseCount;
int totalPulseCount;
int periodCounter;
int remCycle;
int stimProgressTimer = 0;
int stimulationState;
int pulseTotTime; //In millis
int pulseOffTime; //In Millis
int UVOVError =0;
int toogleCounter = 0;
//int preScaler;
bool stimRun;

STIMULATION_TypeDef stimulationSettings;

void MPSTM_SwitchOffStimulationMode(void)
{
	HAL_GPIO_WritePin(MEAS_SWen5V_GPIO_Port, MEAS_SWen5V_Pin, GPIO_PIN_RESET); //Switch off FETS connect electrodes to ADC
	HAL_GPIO_WritePin(MISO2_BT_GPIO_Port, MISO2_BT_Pin, GPIO_PIN_RESET); // MOST pin is temporarily used by Koen to send signal to BT for 
																																			 //enabling the Stmulation voltage
	MPSTM_SetDACValue(0);
	HAL_TIM_Base_DeInit(&htim4);
	HAL_GPIO_WritePin(VSTIM_PWM_GPIO_Port,VSTIM_PWM_Pin,GPIO_PIN_RESET);
	//MPSTM_SetStimVoltage(0);
	MPSTM_DACEnable(false);
	MPSTM_PowerUpShiftReg(false);
	MPSTM_DisableAllSinkElectrodes();
	MPSTM_ShiftRegOutputEnable(false);
	HAL_GPIO_WritePin(STIM_HS_DIS_GPIO_Port, STIM_HS_DIS_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(EN_5V5_GPIO_Port,EN_5V5_Pin,GPIO_PIN_SET);
	MPCP_SendRespGeneral(CMD_TO_BLE_VSTIM_ON,"0"); //switch of VSTIM
	
}
void MPSTM_CalcDACDeltaValue()
{
	dacValueFor1ma = 141;//((float)STIM_DAC_MAXVAL/(float)(STIM_DAC_VREF*1000))*100;
	dacHoldValueForSetCurrent = dacValueFor1ma*stimulationSettings.currentInMa;
	deltaDACStepValue = (float)(dacHoldValueForSetCurrent/(float)stimulationSettings.cyclesFadeL);
}

void MPSTM_SetDACValue(int32_t adcVal )
{
	HAL_DAC_SetValue(&hdac1,DAC_CHANNEL_1,DAC_ALIGN_12B_R,adcVal);
}
/*
IC TPS61170 is used to generate stimulation voltage.
Calculation is given below
Vref = 1.229
Vout = 1.229*(R1/R2+1)
V(fb) = Duty*1.229
Vout = Duty*1.229*(R1/R2+1)
Duty = Vout/(1.229*(R1/R2+1))
Duty = Vout/(34.14)
Total Period = 200 ms
PulseWidth = TotalPeriod * Duty
*/
void MPSTM_SetStimVoltage(float volts)
{
	 if(volts<STIM_VOLTAGE_MIN) volts = STIM_VOLTAGE_MIN;
	 if(volts>STIM_VOLTAGE_MAX) volts = STIM_VOLTAGE_MAX;
	 stimVoltSet = volts;
	 TIM_OC_InitTypeDef sConfigOC = {0};
	 float dutyCycle = volts/STIM_MAX_VOLTAGE;
	 int pulseWidth = (int) (STIM_PWM_PERIOD* dutyCycle+0.5);
	__HAL_TIM_SET_COMPARE( &htim4, TIM_CHANNEL_1, pulseWidth );

/*	HAL_TIM_PWM_Stop_IT(&htim4,TIM_CHANNEL_1);
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = pulseWidth;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
	
	HAL_TIM_PWM_Start_IT(&htim4,TIM_CHANNEL_1);*/
}

void MPSTM_SwitchOnStimVoltage(void)
{
	/* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 55;//166; //Deviser for generating 1 microsecond
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 100; // VSTIM PWM frequency is 30kHz clk freq is 166723 khz 
													 // Diviser need to produce 30Khz from 166723 is 5557
													 // For better resolution 100 is selected as period so prescaler is 55
													 //
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  	HAL_TIM_MspPostInit(&htim4);

	HAL_TIM_PWM_Start_IT(&htim4,TIM_CHANNEL_1);
	//Enable VSTIM 
	HAL_GPIO_WritePin(MISO2_BT_GPIO_Port, MISO2_BT_Pin, GPIO_PIN_SET);
	MPCP_SendRespGeneral(CMD_TO_BLE_VSTIM_ON,"1");
}
//Todo convert as a macro
void MPSTM_SwitchOffStimVoltage(void)
{
	//MPSTM_SetStimVoltage(0);
	HAL_TIM_PWM_Stop_IT(&htim4,TIM_CHANNEL_1);
	HAL_GPIO_WritePin(VSTIM_PWM_GPIO_Port,VSTIM_PWM_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(MISO2_BT_GPIO_Port, MISO2_BT_Pin, GPIO_PIN_RESET);
}

void MPSTM_StimulationTimerInit(int microSec)
{
 /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 168;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = microSec;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV4;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */
  HAL_TIM_Base_Start_IT(&htim1);
  /* USER CODE END TIM1_Init 2 */

}


void ChangeTimerfrequency(int timeMicros)
{
	HAL_TIM_OC_Stop_IT(&htim1, TIM_CHANNEL_1);
	HAL_TIM_OC_Stop(&htim1, TIM_CHANNEL_1);
	htim1.Init.Period = timeMicros;
	TIM_Base_SetConfig(htim1.Instance, &htim1.Init);

	HAL_TIM_OC_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIM_OC_Start_IT(&htim1,TIM_CHANNEL_1);
}

/*
This function is called once before starting the stimulation process
It calculate the pulse off time in micros using stimulation frequnecy
and pulse phase time.

Loads shift regsiter with source electrode settings. Set MC pins for
Sink electrodes

*/
void MPSTM_InitStimulationParams()
{
	//Initialize timer values
	stimulationState = STIM_SATUS_INIT;
	clockPerod = stimulationSettings.pulsePhase;//Counter is programed to generate 50Micro Seccond pulse with pre-scaler . 0.005952380952f;//(int) ((float)(1/(float)STIM_CLOCK_FREQUENCY)*1000000);
	pulseTotTime = (int)((float)(1/(float)stimulationSettings.pulseFrequency)*1000000); 	 //Pulse Tot in micros
	pulseOffTime = pulseTotTime - (stimulationSettings.pulsePhase*2+50); //Pulse Off Time in micro seconds
																																			 //Electrodes toggles after fisrt phase time , and a dead time of 50 ms between that
	pulsePhaseCount = 	((int)(stimulationSettings.pulsePhase));
	totalPulseCount = pulseOffTime/clockPerod;
	periodCounter = 0;
	sequenceCounter = 0;
	stimRun = true;

}
/*
Public function called to start stimulation.
Pre-Requisites : Stimulation structure is initialized
Initialize global variables and settings flags and start the stimulation timer. 
Stimulation is implemented as a simple state machine. Timer function handles 
most of the states.Assumes that Stimulation Global Structure is populated before
calling this function.
*/
void MPSTM_StartStimulation()
{
	MPSTM_InitStimulationParams();
	MPSTM_PowerUp5V(true);
	MPSTM_PowerUpShiftReg(true);
	MPSTM_DACEnable(true);
	MPSTM_SwitchOnStimVoltage();
	MPSTM_SetStimVoltage(10);
	MPSTM_CalcDACDeltaValue();
	stimulationState = STIM_SATUS_ONSET;
	onsetStepCounter = 0;
	//Start initial pulse
	dacCurValue = deltaDACStepValue;
	//init timer for stimulationSettings.pulsePhase
	MPSTM_LoadShiftReg(stimulationSettings.sourceElecs_HS); 
	MPSTM_OnStimTimerPulseSourcePhaseStart();
	MPCP_SendRespStimulationStartReq(STATUS_STIMREQ_OK);
	deviceStatus = STATUS_DEVICE_STIM_RUNNING;
	remCycle = stimulationSettings.seqCountN;
	keepAlive = 0;
	pulseState = PULSE_STATE_START_FIRST_PULSE_PHASE;
	MPSTM_StimulationTimerInit(pulsePhaseCount);
	periodCounter = 0;
	//MPSTM_OnStimulationTimer();

	//MPCP_SendRespStimulationProgress(remCycle,STIM_SATUS_ONSET,dacCurValue);
}

void MPSTM_OnStimTimerPulseSourcePhaseStart()
{
	switch(stimulationState)
	{
		case STIM_SATUS_ONSET:
				MPSTM_DisableAllSinkElectrodes();
			  //Calculate cur dac value
				dacCurValue = deltaDACStepValue * onsetStepCounter;
				//Load DAC value 
				MPSTM_SetDACValue(dacCurValue);	
				MPSTM_ShiftRegLatchLoad();
				MPSTM_EnableSinkElectrodes(stimulationSettings.sinkElecs_LS);
				//Load shift reg with sink electrodes for next phase 
				//Loading ahead to avoid delay
				MPSTM_LoadShiftReg(stimulationSettings.sinkElecs_HS);
				//MPSTM_ReqReadStimVoltHS();
				MPSTM_ShiftRegOutputEnable(true);
				break;
		case STIM_SATUS_HOLD:
			  //Calculate cur dac value incase user change the value
				dacCurValue = deltaDACStepValue * stimulationSettings.cyclesFadeL;
				MPSTM_SetDACValue(dacCurValue);	
				MPSTM_DisableAllSinkElectrodes();
				MPSTM_ShiftRegLatchLoad();
				MPSTM_EnableSinkElectrodes(stimulationSettings.sinkElecs_LS);
				//Load shift reg with sink electrodes for next phase 
				//Loading ahed to avoid delay
				MPSTM_LoadShiftReg(stimulationSettings.sinkElecs_HS); 
			 // MPSTM_ReqReadStimCurrentLS();
				MPSTM_ShiftRegOutputEnable(true);
				break;
		case STIM_SATUS_OFFSET:
				MPSTM_DisableAllSinkElectrodes();
			  //Calculate cur dac value
				dacCurValue = (dacHoldValueForSetCurrent-(deltaDACStepValue * offsetStepCounter));
				//Load DAC value 
				MPSTM_SetDACValue(dacCurValue);
				MPSTM_ShiftRegLatchLoad();
				MPSTM_EnableSinkElectrodes(stimulationSettings.sinkElecs_LS);
				//Load shift reg with sink electrodes for next phase 
				//Loading ahed to avoid delay
				MPSTM_LoadShiftReg(stimulationSettings.sinkElecs_HS); 
				//If onset counter reach max change state
			  MPSTM_ShiftRegOutputEnable(true);
				break;
		case STIM_SATUS_DELAY:
			  //Todo - actually no need to set this every time. optimise later
			  MPSTM_DisableAllSinkElectrodes();
		    MPSTM_ShiftRegOutputEnable(false);
				break;
		
	}

	if(stimRun)
	{
	//Init Timer for PulsePhase 
	//It calls MPSTM_OnStimTimerPulsePhaseEnd() on timer up
	}
}

void MPSTM_OnStimTimerPulseSinkPhaseStart()
{
	
	switch(stimulationState)
	{
		case STIM_SATUS_ONSET:
				MPSTM_DisableAllSinkElectrodes();
				++onsetStepCounter;
			    //Calculate cur dac value
				dacCurValue = deltaDACStepValue * onsetStepCounter;
				//Load DAC value 
				MPSTM_SetDACValue(dacCurValue);
				MPSTM_EnableSinkElectrodes(stimulationSettings.sourceElecs_LS);
				MPSTM_ShiftRegLatchLoad();
				
				//If onset counter reach max change state
		    if(onsetStepCounter >= stimulationSettings.cyclesFadeL)
				{
					onsetStepCounter = 0;
					stimulationState = STIM_SATUS_HOLD;
					holdStateCounter = 0;
					MPCP_SendRespStimulationProgress(remCycle,STIM_SATUS_HOLD,dacCurValue);
					stimProgressTimer = 0;
				}
				//Load shift reg with sink electrodes for next phase 
				//Loading ahed to avoid delay
				MPSTM_LoadShiftReg(stimulationSettings.sourceElecs_HS); 	
				MPSTM_ShiftRegOutputEnable(true);
				break;
		case STIM_SATUS_HOLD:
				MPSTM_DisableAllSinkElectrodes();
				MPSTM_ShiftRegLatchLoad();
				MPSTM_EnableSinkElectrodes(stimulationSettings.sourceElecs_LS);
				//Load shift reg with sink electrodes for next phase 
				//Loading ahed to avoid delay
				MPSTM_LoadShiftReg(stimulationSettings.sourceElecs_HS); 
        MPSTM_ShiftRegOutputEnable(true);		
				++holdStateCounter;
				if(holdStateCounter >= stimulationSettings.cyclesHoldM)
				{
					stimulationState = STIM_SATUS_OFFSET;
					holdStateCounter = 0;
					offsetStepCounter = 0;
					MPCP_SendRespStimulationProgress(remCycle,STIM_SATUS_OFFSET,dacCurValue);
					stimProgressTimer = 0;
				}
			//	MPSTM_ReqReadStimCurrentHS();
				break;
		case STIM_SATUS_OFFSET:
				MPSTM_DisableAllSinkElectrodes();
				//Load DAC value 
				MPSTM_SetDACValue(dacCurValue);
				MPSTM_ShiftRegLatchLoad();
				MPSTM_EnableSinkElectrodes(stimulationSettings.sourceElecs_LS);
				//Load shift reg with sink electrodes for next phase 
				//Loading ahed to avoid delay
				MPSTM_LoadShiftReg(stimulationSettings.sourceElecs_HS); 
				MPSTM_ShiftRegOutputEnable(true);
				//If onset counter reach max change state
		    if(offsetStepCounter >= stimulationSettings.cyclesFadeL)
				{
					onsetStepCounter = 0;
					stimulationState = STIM_SATUS_DELAY;
					holdStateCounter = 0;
					offStateCounter = 0;
					MPCP_SendRespStimulationProgress(remCycle,STIM_SATUS_DELAY,dacCurValue);
					stimProgressTimer = 0;
				}
				++offsetStepCounter;
				break;
		case STIM_SATUS_DELAY:
				MPSTM_DisableAllSinkElectrodes();
				MPSTM_ShiftRegOutputEnable(false);
			  ++offStateCounter;
				
				if(offStateCounter >= stimulationSettings.cyclesDelayK)
				{
					stimulationState = STIM_SATUS_ONSET;
					++sequenceCounter;
					MPCP_SendRespStimulationProgress(remCycle,STIM_SATUS_HOLD,dacCurValue);
					if(sequenceCounter >= stimulationSettings.seqCountN)
					{
						stimRun = false;
						MPSTM_StopStimulation(STATUS_STIMREQ_OK);
						stimProgressTimer = 0;
					}else
					{
						//TODO check whether Battory, lead off all in good condition before proceeding to
						//next cycle. If any error stop stimulation
						remCycle = stimulationSettings.seqCountN-sequenceCounter;
						MPSTM_AdjVstimVoltage();
					
					}
				}
				
				break;
		
	}
	//send status evry 100 milli seconds
	
	if(stimRun)
	{
	//	MPSTM_StartTimerPulsePhase(stimulationSettings.pulsePhase);
	//Init Timer for PulsePhase 
	//It calls MPSTM_OnStimTimerPulsePhaseEnd() on timer up
	}
}

bool MPSTM_StopStimulationOnError(void)
{
	
	if(disableKeepAlive == false)
	{
		if(keepAlive>KEEP_ALIVE_TIME_OUT)
		{
			MPSTM_StopStimulation(STATUS_STIMREQ_APP_NOT_RESPONDING);
			return true;
		}
	}
	if(batteryPercent < 5)
	{
		MPSTM_StopStimulation(STATUS_STIMREQ_BATLOW);
		return true;
	}
	if(powerConnected)
	{
		MPSTM_StopStimulation(STATUS_STIMREQ_MAINS_CONNECTED);
		return true;
	}
	if(!bleConnected)
	{
		MPSTM_StopStimulation(STATUS_STIMREQ_LOST_CON);
		return true;
	}
	if(UVOVError>0)
	{
		//MPSTM_StopStimulation(STATUS_STIMREQ_INVALID_CURRENT);
		UVOVError=0;
		return true;
	}
	return false;
}

/*
//Counter is programed to generate 50Micro Seccond pulses 
//Pulse Pattern is as given below
//-----__-----___________________________-----__-----_______________
//
//PulsePhase-deadtime50Micros-PulsePhase(Toggled SourceSink)-delaytime
//
 */

void StimWaveFormTester()
{
	 if(toogleCounter==0)
	 {
//		 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_SET);
		 __HAL_TIM_SetAutoreload(&htim1,pulsePhaseCount);
		 __HAL_TIM_SetCounter(&htim1, 0);
		 toogleCounter=1;
	 }
	 else if(toogleCounter==1)
	 {
//		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
		__HAL_TIM_SetAutoreload(&htim1,250);
		__HAL_TIM_SetCounter(&htim1, 0);
		toogleCounter=2;
	 }
	 else if(toogleCounter==2)
	 {
//		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_SET);
		__HAL_TIM_SetAutoreload(&htim1,pulsePhaseCount);
		__HAL_TIM_SetCounter(&htim1, 0);
		toogleCounter=3;
	 }
	  else if(toogleCounter==3)
	  {
//		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);		
		__HAL_TIM_SetAutoreload(&htim1,pulseOffTime);
		__HAL_TIM_SetCounter(&htim1, 0);
		toogleCounter=0;
	}
}
//Counter is programed to generate 50Micro Seccond pulses 
//Pulse Pattern is as given below
//-----__-----___________________________-----__-----_______________
//
//PulsePhase-deadtime50Micros-PulsePhase(Toggled SourceSink)-delaytime
//
//

void MPSTM_OnStimulationTimer(void)
{
	
	  if(MPSTM_StopStimulationOnError()) return;
		
		if(pulseState == PULSE_STATE_START_FIRST_PULSE_PHASE) //First pulse phase completed . Start Dead Time
			{
			 ++periodCounter;
//			 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_SET);
			 MPSTM_OnStimTimerPulseSourcePhaseStart();
			 __HAL_TIM_SetAutoreload(&htim1,pulsePhaseCount);
			 __HAL_TIM_SetCounter(&htim1, 0);
			 pulseState = PULSE_STATE_START_DEAD_TIME; //Set Next state 
			}
		else if(pulseState == PULSE_STATE_START_DEAD_TIME)
		{
			 ++periodCounter;
			// HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			 MPSTM_DisableAllSinkElectrodes();
			 MPSTM_ShiftRegOutputEnable(false);
			 __HAL_TIM_SetAutoreload(&htim1,PULSE_DEAD_TIME);
			 __HAL_TIM_SetCounter(&htim1, 0);
			 pulseState = PULSE_STATE_START_SECOND_PULSE_PHASE; //Set next pulse state
		 }
		else if(pulseState == PULSE_STATE_START_SECOND_PULSE_PHASE) //50 micro second sleep between source / sink swap
		 {
				++periodCounter;
			  MPSTM_OnStimTimerPulseSinkPhaseStart();
			 
			//  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_SET);
			  __HAL_TIM_SetAutoreload(&htim1,pulsePhaseCount);
		    __HAL_TIM_SetCounter(&htim1, 0);
			  pulseState = PULSE_STATE_START_OFFTIME; //Set next pulse state
		 }
		 else if(pulseState == PULSE_STATE_START_OFFTIME)
		 {
			  periodCounter = 0;
		//	  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			  MPSTM_OnStimTimerPulsePhaseEnd();
			  MPSTM_ShiftRegOutputEnable(false);
			  __HAL_TIM_SetAutoreload(&htim1,pulseOffTime);
		    __HAL_TIM_SetCounter(&htim1, 0);
			  pulseState = PULSE_STATE_START_FIRST_PULSE_PHASE; 
		 }
		 if(stimProgressTimer > 200)
		 {
			MPCP_SendRespStimulationProgress(remCycle,stimulationState,dacCurValue);
			stimProgressTimer = 0;
		 }
	}
/*
 This timer function is triggered at the end of pulse phase
 It switch of current sources and start the timer for pulse off 
 duration. At the end pulse off duration it triggers MPSTM_OnStimTimerPulsePhaseStart()
*/
void MPSTM_OnStimTimerPulsePhaseEnd()
{
	//MPSTM_ShiftRegOutputEnable(false);
	MPSTM_DisableAllSinkElectrodes();
	if(stimRun)
	{
	//init Timer for pulse off pahase 
	//It calls MPSTM_OnStimTimerPulsePhaseStart()on timer up
	}
}
//
void MPSTM_StimulationParser(char * stimationParams)
{
}

void MPSTM_DACEnable(bool onOff)
{
	if(onOff)
	{
		/*ISTIM_DACena_Pin Pin set to high*/
		HAL_DAC_Start(&hdac1,DAC_CHANNEL_1);
		HAL_GPIO_WritePin(ISTIM_DACena_GPIO_Port,ISTIM_DACena_Pin,GPIO_PIN_SET);
	}
	else
	{
		/*ISTIM_DACena_Pin Pin set to low*/
		HAL_GPIO_WritePin(ISTIM_DACena_GPIO_Port,ISTIM_DACena_Pin,GPIO_PIN_RESET);
	}
}

void MPSTM_PowerUp5V(bool onOff)
{
	if(onOff)
	{
		/*ENA Pin set to high*/
		HAL_GPIO_WritePin(EN_5V5_GPIO_Port,EN_5V5_Pin,GPIO_PIN_SET);//need to check the proper pin selection EN_5V5_GPIO_Port
	}else
	{
		/*ENA Pin set to low*/
		HAL_GPIO_WritePin(EN_5V5_GPIO_Port,EN_5V5_Pin,GPIO_PIN_RESET);//EN_5V5_GPIO_Port
	}
}

void MPSTM_PowerUpShiftReg(bool onOff)
{
	if(onOff)
	{
		/*ENA Pin set to high*/
		HAL_GPIO_WritePin(STIM_HS_ENA_GPIO_Port,STIM_HS_ENA_Pin,GPIO_PIN_SET);
	}
	else
	{
		/*ENA Pin set to low*/
		HAL_GPIO_WritePin(STIM_HS_ENA_GPIO_Port,STIM_HS_ENA_Pin,GPIO_PIN_RESET);
	}
}

uint32_t MPSTM_SourceEleccnvt(uint8_t * SeElec)
{
	uint32_t sElec = 0;
	uint32_t temp;
	sElec = (SeElec[2] << 16 | SeElec[1] << 8 | SeElec[0]);
	uint32_t sElec_nval = 0;
	for(int ch = 0; ch < STIM_CHANNELS ; ch++, sElec >>= 1)
	{
		if(sElec & 1) 
		{
		temp = sh_l(sTim_HS[ch]);
		sElec_nval |= temp;
		}
		//sElec = sElec>>1;
	}
	return sElec_nval;
}

void MPSTM_LoadShiftReg(uint8_t * SourceElec)
{

	if(HAL_SPI_Transmit(&hspi1,SourceElec,4,10)!= HAL_OK)
		Error_Handler();
	while (!__HAL_SPI_GET_FLAG(&hspi1, SPI_FLAG_TXE));
}

void MPSTM_ShiftRegLatchLoad(void)
{
	/*LOAD Pin set to high*/
	HAL_GPIO_WritePin(STIM_HS_LOAD_GPIO_Port,STIM_HS_LOAD_Pin,GPIO_PIN_SET);
}

/* SET STIM_HS_OE pin to enable the OE pin of shift register.*/
void MPSTM_ShiftRegOutputEnable(bool enable)
{
	if(enable)
	{		
		/*LOAD Pin set to high lod the output latch- loading is donr on rising edge*/
		HAL_GPIO_WritePin(STIM_HS_LOAD_GPIO_Port,STIM_HS_LOAD_Pin,GPIO_PIN_SET);

		/*OE Pin set to low to enable output */
		HAL_GPIO_WritePin(STIM_HS_OE_GPIO_Port,STIM_HS_OE_Pin,GPIO_PIN_RESET);
	}
	else
	{
		/*LOAD Pin set to low*/
		HAL_GPIO_WritePin(STIM_HS_LOAD_GPIO_Port,STIM_HS_LOAD_Pin,GPIO_PIN_RESET);
		/*OE Pin set to high*/
		HAL_GPIO_WritePin(STIM_HS_OE_GPIO_Port,STIM_HS_OE_Pin,GPIO_PIN_SET);
	
	}
		
}

//Set all sink elctrodes low state 
void MPSTM_DisableAllSinkElectrodes()
{
	GPIOD->ODR = 0x0000U;
	GPIOE->ODR &= 0x00ff;
	/*uint16_t GPIOD_16pin = 0x0000;
	uint16_t GPIOE_17_24pin = GPIOE->ODR;
	GPIOE_17_24pin &= 
	GPIOD->ODR = GPIOD_16pin;
	GPIOE->ODR = GPIOE_17_24pin;*/
}

uint32_t MPSTM_sinkElectrodecnvrt(uint8_t* sinkElec)
{
	//STIMULATION_TypeDef electstate;
	uint32_t skElectrode = 0;
	uint32_t temp;
	skElectrode = sinkElec[2]<<16|sinkElec[1]<<8 | sinkElec[0] ;
	uint32_t skElec_val = 0;
	
	for(int ch =0;ch<STIM_CHANNELS;ch++,skElectrode>>=1)
	{
		if(skElectrode & 1) 
		{
			temp = sh_l(sTim_LS[ch]);
			skElec_val|= temp;
		}
		//skElectrode = skElectrode>>1;
	}
	return skElec_val;
	
}

void MPSTM_SourceSink_bufferload(uint8_t* sourceEle,uint8_t* sinkEle)
{
	
	uint32_t so_HS,sk_LS,sk_HS,so_LS =0;
	
	so_HS = MPSTM_SourceEleccnvt(sourceEle);
	stimulationSettings.sourceElecs_HS[0] = (uint8_t)~(so_HS);
	stimulationSettings.sourceElecs_HS[1] = (uint8_t)~(so_HS>>8);
	stimulationSettings.sourceElecs_HS[2] = (uint8_t)~(so_HS>>16);
	stimulationSettings.sourceElecs_HS[3] = (uint8_t)~(so_HS>>24);
	
	sk_LS = MPSTM_sinkElectrodecnvrt(sinkEle);
	stimulationSettings.sinkElecs_LS[0] = (uint8_t)sk_LS;
	stimulationSettings.sinkElecs_LS[1] = (uint8_t)(sk_LS>>8);
	stimulationSettings.sinkElecs_LS[2] = (uint8_t)(sk_LS>>16);
	
	sk_HS = MPSTM_SourceEleccnvt(sinkEle);
	stimulationSettings.sinkElecs_HS[0] = (uint8_t)~(sk_HS);
	stimulationSettings.sinkElecs_HS[1] = (uint8_t)~(sk_HS>>8);
	stimulationSettings.sinkElecs_HS[2] = (uint8_t)~(sk_HS>>16);
	stimulationSettings.sinkElecs_HS[3] = (uint8_t)~(sk_HS>>24);
	
	so_LS = MPSTM_sinkElectrodecnvrt(sourceEle);
	stimulationSettings.sourceElecs_LS[0] = (uint8_t)so_LS;
	stimulationSettings.sourceElecs_LS[1] = (uint8_t)(so_LS>>8);
	stimulationSettings.sourceElecs_LS[2] = (uint8_t)(so_LS>>16);
	
}

void MPSTM_EnableSinkElectrodes(uint8_t *sinkElectrodes)
{
	GPIOD->ODR =  0x0000U;
	GPIOE->ODR &= 0x00ff;
	uint16_t GPIOD_16pin = (uint16_t)sinkElectrodes[1]<<8 | sinkElectrodes[0];
	uint16_t GPIOE_17_24pin = GPIOE->ODR;
	GPIOE_17_24pin |= (uint16_t)sinkElectrodes[2]<<8 & 0xFF00;
 	GPIOD->ODR = GPIOD_16pin;
	GPIOE->ODR = GPIOE_17_24pin;
}

void MPSTM_StopStimulation(int status)
{
	HAL_TIM_OC_Stop(&htim1, TIM_CHANNEL_1);
	
	MPSTM_SwitchOffStimVoltage();
	MPSTM_PowerUp5V(false);
	MPSTM_SetDACValue(0);
	MPSTM_DACEnable(false);
	MPSTM_PowerUpShiftReg(false);
	
	MPSTM_DisableAllSinkElectrodes();
	MPSTM_ShiftRegOutputEnable(false);
	HAL_GPIO_WritePin(MISO2_BT_GPIO_Port,MISO2_BT_Pin,GPIO_PIN_RESET);
	MPCP_SendRespStimulationStopReq(status);
	deviceStatus= STATUS_DEVICE_IDLE;
}

bool MPSTM_ExecStimulationRequest(void)
{
	if(deviceStatus == STATUS_DEVICE_STIM_RUNNING)
	{
		MPSTM_StopStimulation(STATUS_STIMREQ_OK);
	}
	if(MPCP_ParseStimulationRequest() == true)
	{
		MPSTM_StartStimulation();
	}
	else
	{
		//TODO send back error response;
	}
	return true;
}

bool MPSTM_ReqReadStimCurrentLS(void)
{
	return MPSM_ReadADC1(ADC_READ_ISTIM_LSADC);
}

/*
ADC wordSize =4096
ADC Ref Voltage = 3.3
SenseV =(ADC Val/4096)*3.3
V CurSense = SenseV/48
Stim Current = V CurSense/ CurSense Res
CurSense Res = 1 ohm
*/
void MPSTM_OnReadStimCurrentLS(uint32_t adcValue)
{
	float sv = ((float)adcValue/(float)STIM_ADC_MAXVAL)*(float)STIM_ADC_REF_VOLTAGE;
	stimCurrentLS = sv /STIM_CS_AMP_FACTOR;
}

bool MPSTM_ReqReadStimCurrentHS(void)
{
	return MPSM_ReadADC1(ADC_READ_ISTIM_HSADC);
	//return true;
}
/*
Ref MAX MAX17612A Manual
ADC Word = 4096
ADC Ref V = 3.3 V
Rseti = 7500 ohm
CIRATIO = 200 typical 
Vseti = (AdcVal /4096)*3.3
Iseti = Vseti/7500
Iout = iSeti*200
*/
void MPSTM_OnReadStimCurrentHS(uint32_t adcValue)
{
	/*char buf [50];
	sprintf(buf,"HSi=%d\n",adcValue);
	HAL_UART_Transmit(&huart4,(uint8_t*)buf,strlen(buf),10);
	MPSTM_ReqReadStimVoltHS();*/
	float sv = ((float)adcValue/(float)STIM_ADC_MAXVAL)*(float)STIM_ADC_REF_VOLTAGE;
	stimCurrentHS = (float)(sv/(float)7500)*(float)200;
}


bool MPSTM_ReqReadStimVoltHS(void)
{
	return MPSM_ReadADC1(ADC_READ_VSTIM_HS);
}
/*
VSense  =( ADC Val /4096)*3.3
Vstim = Vsense*(R1+R2)/R1
(R1+R2)/R1= (5600+150000)/5600
					=27.78
*/
void MPSTM_OnReadStimVoltHS(uint32_t adcValue)
{
	/*char buf [50];
	sprintf(buf,"HSV=%d\n",adcValue);
	HAL_UART_Transmit(&huart4,(uint8_t*)buf,strlen(buf),10);
	MPSTM_ReqReadStimCurrentHS();*/
	float sv = ((float)adcValue/(float)STIM_ADC_MAXVAL)*(float)STIM_ADC_REF_VOLTAGE;
	stimVoltageHS = sv*27.78;
	
}



void MPSTM_AdjVstimVoltage(void)
{
	MPSTM_SetStimVoltage(10);
	return;
	if(stimCurrentLS>stimulationSettings.currentInMa)
	{
		float stimVoltToSet =stimVoltSet-2;
		MPSTM_SetStimVoltage(stimVoltToSet);
	}
	if((stimCurrentLS+STIM_MEAS_CUR_DIFF_FROM_SET_CUR)<stimulationSettings.currentInMa)
	{
		double stimVoltToSet =stimVoltSet+2.5;
		MPSTM_SetStimVoltage(stimVoltToSet);
	}
}


/*
This function is called from stimulation timer interrupt service routine.
When time is up for pulse phase
Most of the work is done from here based on the stimulation state variable.
Tasks to be done on each state

STIM_SATUS_ONSET
	If highLowState is high- switch on source and sink ckts steps below
	Load DAC value- curDACOutVale to DAC
	Output Enable Shift register
	Adjust  curDACOutVale to next step value by adding dacDeltaValue increment.
	highLowState set to zero
	If highLowState is low -> Switch off source and sink ckts steps below
	Output Tristate Shift register
	Increment onsetCounter
	If onsetCounter> L set state to STIM_SATUS_HOLD
	highLowState set to zero.
	Increment pulseCounter
STIM_SATUS_HOLD
	If highLowState is high-switch on source and sink ckts steps below
	Output Enable Shift register
	highLowState set to zero
	If highLowState is low -> Switch off source and sink ckts steps below
	Output Tristate Shift register
	Increment holdCounter
	If holdCounter> M set state to STIM_SATUS_OFFSET
	highLowState set to one.
STIM_SATUS_OFFSET
	If highLowState is high- switch on source and sink ckts steps below
	Load DAC value- curDACOutVale to DAC
	Output Enable Shift register
	Adjust  curDACOutVale to next step value by subtracting dacDeltaValue.
	highLowState set to zero
	If highLowState is low -> Switch off source and sink ckts steps below
	Output Tristate Shift register
	Increment offsetCounter
	If offsetCounter> L set state to STIM_SATUS_DELAY
	highLowState set to one.
	Increment pulseCounter
STIM_SATUS_DELAY
	If highLowState is high-switch on source and sink ckts steps below
	Output Tristate Shift register
	highLowState set to zero
	If highLowState is low -> Switch off source and sink ckts steps below
	Output Tristate Shift register
	Increment delayCounter
	Increment pulseCounter
	If delayCounter> M
	set state to STIM_SATUS_OFFSET
	If pulseCounter > totPulseCounter set state to STIM_SATUS_STOP
	highLowState set to one.
*/
